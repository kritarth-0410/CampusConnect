/**
 * Person 3: Ticket Data Model, Repository & Persistence Store
 * Provides persistent JSON file storage backed by in-memory indexing,
 * realistic campus maintenance seed data, and strict status history auditing.
 */

import fs from 'fs';
import path from 'path';
import {
  Department,
  DuplicateCandidate,
  StatusHistoryEntry,
  Ticket,
  TicketCategory,
  TicketStatus
} from '../shared/types.js';

const DATA_DIR = path.resolve(process.cwd(), '.data');
const DB_FILE = path.join(DATA_DIR, 'tickets.json');

class TicketRepository {
  private tickets: Map<string, Ticket> = new Map();
  private nextIdCounter: number = 1005;
  private isStorageInitialized: boolean = false;

  constructor() {
    this.initStore();
  }

  private initStore() {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }

      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const data = JSON.parse(raw);
        if (Array.isArray(data.tickets)) {
          for (const t of data.tickets) {
            this.tickets.set(t.id, t);
          }
          if (typeof data.nextIdCounter === 'number') {
            this.nextIdCounter = data.nextIdCounter;
          }
          console.log(`[TicketStore] Loaded ${this.tickets.size} tickets from disk persistence.`);
          this.isStorageInitialized = true;
          return;
        }
      }
    } catch (err) {
      console.warn('[TicketStore] Could not read disk persistence, seeding fresh store:', err);
    }

    // Seed realistic demo tickets across all four categories
    this.seedDefaultTickets();
    this.persistToDisk();
    this.isStorageInitialized = true;
  }

  private persistToDisk() {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      const payload = {
        updatedAt: new Date().toISOString(),
        storageType: 'file-backed-json-store',
        nextIdCounter: this.nextIdCounter,
        tickets: Array.from(this.tickets.values())
      };
      fs.writeFileSync(DB_FILE, JSON.stringify(payload, null, 2), 'utf-8');
    } catch (err) {
      console.error('[TicketStore] Failed to write to disk:', err);
    }
  }

  private seedDefaultTickets() {
    const now = Date.now();
    const timeAgo = (mins: number) => new Date(now - mins * 60 * 1000).toISOString();

    const seeds: Ticket[] = [
      {
        id: 'CC-1001',
        title: 'Continuous pipe leak under 2nd floor sink',
        description: 'Water is dripping steadily onto the tile floor from the second sink pipe in the west wing washroom. Floor is slippery.',
        rawStudentInput: 'Hey washroom near room 204 has water dripping from the sink pipe onto the floor someone might slip',
        category: 'Plumbing',
        categorySource: 'ai_suggested',
        location: 'West Wing Men\'s Restroom 2nd Floor',
        building: 'Science & Engineering Complex',
        roomOrArea: 'Restroom opposite Room 204',
        studentName: 'Alex Chen',
        studentEmail: 'alex.chen@campus.edu',
        status: 'In Progress',
        createdAt: timeAgo(140),
        updatedAt: timeAgo(20),
        aiAnalysis: {
          suggestedCategory: 'Plumbing',
          confidence: 'High',
          confidenceScore: 0.94,
          conciseSummary: 'Continuous pipe leak under washbasin causing slip hazard.',
          recommendedDepartment: 'Plumbing Maintenance Department',
          missingDetailsIdentified: [],
          followUpQuestions: [],
          urgencyAssessment: 'Moderate',
          analyzedAt: timeAgo(140)
        },
        assignment: {
          department: 'Plumbing Maintenance Department',
          assignedTo: 'Carlos Rivera (Master Plumber)',
          assignedAt: timeAgo(90),
          assignedBy: 'Campus Dispatch Triage',
          priority: 'High',
          notes: 'Dispatched with replacement P-trap seal and warning cones.'
        },
        statusHistory: [
          {
            id: 'h-1',
            ticketId: 'CC-1001',
            toStatus: 'Submitted',
            changedAt: timeAgo(140),
            changedBy: 'Student Portal (Alex Chen)',
            notes: 'Complaint submitted with high AI confidence triage.'
          },
          {
            id: 'h-2',
            ticketId: 'CC-1001',
            fromStatus: 'Submitted',
            toStatus: 'Under Review',
            changedAt: timeAgo(110),
            changedBy: 'Triage Supervisor Sarah M.',
            notes: 'Verified location and slip hazard potential.'
          },
          {
            id: 'h-3',
            ticketId: 'CC-1001',
            fromStatus: 'Under Review',
            toStatus: 'Assigned',
            changedAt: timeAgo(90),
            changedBy: 'Triage Supervisor Sarah M.',
            notes: 'Assigned to Plumbing Maintenance Division.'
          },
          {
            id: 'h-4',
            ticketId: 'CC-1001',
            fromStatus: 'Assigned',
            toStatus: 'In Progress',
            changedAt: timeAgo(20),
            changedBy: 'Technician Carlos Rivera',
            notes: 'On site, valve shut off, currently fitting new pipe connector.'
          }
        ]
      },
      {
        id: 'CC-1002',
        title: 'Lecture hall 101 power socket sparking and tripped breaker',
        description: 'The surge strip plug at desk row 3 sparked when a student plugged in their laptop. Burning ozone smell noticed.',
        rawStudentInput: 'There was a spark and popping sound from row 3 plug in hall 101 during physics lecture. Outlet smells burnt.',
        category: 'Electricity',
        categorySource: 'ai_suggested',
        location: 'Lecture Hall 101, Row 3 Desk Strip',
        building: 'Main Academic Quad',
        roomOrArea: 'Hall 101',
        studentName: 'Priya Patel',
        studentEmail: 'p.patel@campus.edu',
        status: 'Assigned',
        createdAt: timeAgo(75),
        updatedAt: timeAgo(45),
        aiAnalysis: {
          suggestedCategory: 'Electricity',
          confidence: 'High',
          confidenceScore: 0.98,
          conciseSummary: 'Power strip electrical arc spark and ozone odor in lecture hall.',
          recommendedDepartment: 'Electrical Systems & Safety Division',
          missingDetailsIdentified: [],
          followUpQuestions: [],
          urgencyAssessment: 'Safety Hazard',
          analyzedAt: timeAgo(75)
        },
        assignment: {
          department: 'Electrical Systems & Safety Division',
          assignedTo: 'Marcus Vance (Senior Electrician)',
          assignedAt: timeAgo(45),
          assignedBy: 'Duty Dispatcher',
          priority: 'Emergency',
          notes: 'Circuit 12B breaker locked out remotely, electrician inspecting wiring.'
        },
        statusHistory: [
          {
            id: 'h-5',
            ticketId: 'CC-1002',
            toStatus: 'Submitted',
            changedAt: timeAgo(75),
            changedBy: 'Student Portal (Priya Patel)',
            notes: 'Urgent electrical hazard reported.'
          },
          {
            id: 'h-6',
            ticketId: 'CC-1002',
            fromStatus: 'Submitted',
            toStatus: 'Assigned',
            changedAt: timeAgo(45),
            changedBy: 'Safety Officer James K.',
            notes: 'Fast-tracked directly to Electrical Systems due to electrical safety rating.'
          }
        ]
      },
      {
        id: 'CC-1003',
        title: 'Recycling station overflow and sticky beverage spill',
        description: 'Large soda cups and food containers spilled across floor by the central courtyard entry stairs. High foot traffic.',
        rawStudentInput: 'Huge spill near courtyard stairs and trash bins are overflowing with drink cups everywhere',
        category: 'Cleanliness',
        categorySource: 'student',
        location: 'Courtyard Entry Foyer, Ground Floor',
        building: 'Student Union Center',
        roomOrArea: 'Stairwell B Entrance',
        studentName: 'Jordan Taylor',
        studentEmail: 'j.taylor@campus.edu',
        status: 'Under Review',
        createdAt: timeAgo(50),
        updatedAt: timeAgo(30),
        aiAnalysis: {
          suggestedCategory: 'Cleanliness',
          confidence: 'High',
          confidenceScore: 0.92,
          conciseSummary: 'Overfilled waste receptacles and sticky liquid spill at primary stairwell.',
          recommendedDepartment: 'Campus Custodial & Sanitation Services',
          missingDetailsIdentified: [],
          followUpQuestions: [],
          urgencyAssessment: 'Moderate',
          analyzedAt: timeAgo(50)
        },
        statusHistory: [
          {
            id: 'h-7',
            ticketId: 'CC-1003',
            toStatus: 'Submitted',
            changedAt: timeAgo(50),
            changedBy: 'Student Portal (Jordan Taylor)',
            notes: 'Cleanliness service request logged.'
          },
          {
            id: 'h-8',
            ticketId: 'CC-1003',
            fromStatus: 'Submitted',
            toStatus: 'Under Review',
            changedAt: timeAgo(30),
            changedBy: 'Shift Supervisor Elena Gomez',
            notes: 'Custodial team lead notified for sweep.'
          }
        ]
      },
      {
        id: 'CC-1004',
        title: 'eduroam Wi-Fi drops continually in 3rd floor quiet zone',
        description: 'Access Point AP-North-3F appears to be failing DHCP leases or rejecting auth. 20+ study desks unable to connect.',
        rawStudentInput: 'Internet keeps disconnecting every minute on the 3rd floor library. None of our laptops can stay on eduroam.',
        category: 'Internet Connectivity',
        categorySource: 'ai_suggested',
        location: '3rd Floor North Quiet Study Wing',
        building: 'University Memorial Library',
        roomOrArea: 'Desks 301-325',
        studentName: 'Devon Lee',
        studentEmail: 'devon.l@campus.edu',
        status: 'Resolved',
        createdAt: timeAgo(320),
        updatedAt: timeAgo(60),
        resolvedAt: timeAgo(60),
        aiAnalysis: {
          suggestedCategory: 'Internet Connectivity',
          confidence: 'High',
          confidenceScore: 0.95,
          conciseSummary: 'Repeated wireless disconnection and DHCP negotiation failures on Library 3F AP.',
          recommendedDepartment: 'IT & Network Infrastructure Team',
          missingDetailsIdentified: [],
          followUpQuestions: [],
          urgencyAssessment: 'Moderate',
          analyzedAt: timeAgo(320)
        },
        assignment: {
          department: 'IT & Network Infrastructure Team',
          assignedTo: 'NOC Tech Maya Lin',
          assignedAt: timeAgo(280),
          assignedBy: 'Automated IT Ticketing',
          priority: 'High',
          notes: 'Remote diagnostics performed on Cisco AP-302.'
        },
        statusHistory: [
          {
            id: 'h-9',
            ticketId: 'CC-1004',
            toStatus: 'Submitted',
            changedAt: timeAgo(320),
            changedBy: 'Student Portal (Devon Lee)',
            notes: 'Network connectivity ticket generated.'
          },
          {
            id: 'h-10',
            ticketId: 'CC-1004',
            fromStatus: 'Submitted',
            toStatus: 'Assigned',
            changedAt: timeAgo(280),
            changedBy: 'Network Operations Desk',
            notes: 'Routed to campus wireless engineering.'
          },
          {
            id: 'h-11',
            ticketId: 'CC-1004',
            fromStatus: 'Assigned',
            toStatus: 'In Progress',
            changedAt: timeAgo(150),
            changedBy: 'NOC Tech Maya Lin',
            notes: 'Rebooted local PoE switch port and updated AP firmware.'
          },
          {
            id: 'h-12',
            ticketId: 'CC-1004',
            fromStatus: 'In Progress',
            toStatus: 'Resolved',
            changedAt: timeAgo(60),
            changedBy: 'NOC Tech Maya Lin',
            notes: 'AP rebooted and ping stability verified across all 24 connected clients.'
          }
        ]
      }
    ];

    for (const s of seeds) {
      this.tickets.set(s.id, s);
    }
  }

  public getAll(): Ticket[] {
    return Array.from(this.tickets.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  public getById(id: string): Ticket | undefined {
    const cleanId = id.trim().toUpperCase();
    return this.tickets.get(cleanId);
  }

  public createTicket(params: {
    description: string;
    location: string;
    building: string;
    roomOrArea?: string;
    category: TicketCategory;
    categorySource?: 'student' | 'ai_suggested';
    studentName?: string;
    studentEmail?: string;
    imageBase64?: string;
    mimeType?: string;
    aiAnalysis?: any;
    studentFollowUpAnswers?: Record<string, string>;
    duplicateWarnings?: DuplicateCandidate[];
  }): Ticket {
    const id = `CC-${this.nextIdCounter++}`;
    const now = new Date().toISOString();

    const title = params.aiAnalysis?.conciseSummary
      ? params.aiAnalysis.conciseSummary.slice(0, 90)
      : params.description.slice(0, 80);

    const initialHistoryEntry: StatusHistoryEntry = {
      id: `hist-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      ticketId: id,
      toStatus: 'Submitted',
      changedAt: now,
      changedBy: params.studentName ? `Student (${params.studentName})` : 'Student (Anonymous)',
      notes: 'Complaint submitted through student portal.'
    };

    let imageDataUri: string | undefined = undefined;
    if (params.imageBase64 && params.mimeType) {
      imageDataUri = `data:${params.mimeType};base64,${params.imageBase64.replace(/^data:[^;]+;base64,/, '')}`;
    }

    const newTicket: Ticket = {
      id,
      title,
      description: params.description,
      rawStudentInput: params.description,
      category: params.category,
      categorySource: params.categorySource || 'student',
      location: params.location,
      building: params.building,
      roomOrArea: params.roomOrArea,
      studentName: params.studentName,
      studentEmail: params.studentEmail,
      imageDataUri,
      status: 'Submitted',
      createdAt: now,
      updatedAt: now,
      aiAnalysis: params.aiAnalysis,
      statusHistory: [initialHistoryEntry],
      duplicateWarnings: params.duplicateWarnings || [],
      studentFollowUpAnswers: params.studentFollowUpAnswers || {},
      staffNotes: []
    };

    this.tickets.set(id, newTicket);
    this.persistToDisk();
    return newTicket;
  }

  public assignTicket(
    id: string,
    department: Department,
    assignedTo?: string,
    priority: 'Low' | 'Medium' | 'High' | 'Emergency' = 'Medium',
    notes?: string,
    assignedBy: string = 'Staff Coordinator'
  ): Ticket | undefined {
    const ticket = this.getById(id);
    if (!ticket) return undefined;

    const now = new Date().toISOString();
    ticket.assignment = {
      department,
      assignedTo: assignedTo?.trim() || undefined,
      assignedAt: now,
      assignedBy,
      priority,
      notes: notes?.trim() || undefined
    };

    const previousStatus = ticket.status;
    // Auto transition to Assigned if currently Submitted or Under Review
    if (ticket.status === 'Submitted' || ticket.status === 'Under Review') {
      ticket.status = 'Assigned';
    }

    ticket.updatedAt = now;
    ticket.statusHistory.push({
      id: `hist-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      ticketId: id,
      fromStatus: previousStatus,
      toStatus: ticket.status,
      changedAt: now,
      changedBy: assignedBy,
      notes: `Assigned to ${department}${assignedTo ? ` (${assignedTo})` : ''}.${notes ? ` Note: ${notes}` : ''}`
    });

    this.persistToDisk();
    return ticket;
  }

  public updateStatus(
    id: string,
    newStatus: TicketStatus,
    notes?: string,
    changedBy: string = 'Staff Officer'
  ): Ticket | undefined {
    const ticket = this.getById(id);
    if (!ticket) return undefined;

    const previousStatus = ticket.status;
    const now = new Date().toISOString();

    ticket.status = newStatus;
    ticket.updatedAt = now;

    if (newStatus === 'Resolved') {
      ticket.resolvedAt = now;
    } else {
      ticket.resolvedAt = undefined;
    }

    ticket.statusHistory.push({
      id: `hist-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      ticketId: id,
      fromStatus: previousStatus,
      toStatus: newStatus,
      changedAt: now,
      changedBy,
      notes: notes || `Status updated to ${newStatus}`
    });

    this.persistToDisk();
    return ticket;
  }

  public getStats() {
    const all = this.getAll();
    const stats = {
      total: all.length,
      submitted: 0,
      underReview: 0,
      assigned: 0,
      inProgress: 0,
      resolved: 0,
      byCategory: {
        'Plumbing': 0,
        'Electricity': 0,
        'Cleanliness': 0,
        'Internet Connectivity': 0
      } as Record<TicketCategory, number>
    };

    for (const t of all) {
      if (t.status === 'Submitted') stats.submitted++;
      else if (t.status === 'Under Review') stats.underReview++;
      else if (t.status === 'Assigned') stats.assigned++;
      else if (t.status === 'In Progress') stats.inProgress++;
      else if (t.status === 'Resolved') stats.resolved++;

      if (stats.byCategory[t.category] !== undefined) {
        stats.byCategory[t.category]++;
      }
    }

    return stats;
  }

  public getStorageStatus() {
    return {
      storageType: 'Persistent File-Backed JSON Store',
      storageFile: DB_FILE,
      isInitialized: this.isStorageInitialized,
      recordCount: this.tickets.size
    };
  }
}

export const ticketRepository = new TicketRepository();
