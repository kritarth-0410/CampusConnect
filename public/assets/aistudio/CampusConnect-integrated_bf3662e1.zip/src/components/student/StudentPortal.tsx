import React, { useState } from 'react';
import {
  Wrench,
  Zap,
  Sparkles,
  Wifi,
  Search,
  ArrowRight,
  ShieldCheck,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Building2,
  HardHat,
  MessageSquare
} from 'lucide-react';
import { ComplaintForm } from './ComplaintForm.js';
import { TicketConfirmation } from './TicketConfirmation.js';
import { TicketTracker } from './TicketTracker.js';
import { Ticket, TicketCategory } from '../../shared/types.js';

interface StudentPortalProps {
  onNavigateToStaff: () => void;
  onOpenDemoGuide: () => void;
  initialMode?: 'report' | 'track';
  initialTicketId?: string;
}

export const StudentPortal: React.FC<StudentPortalProps> = ({
  onNavigateToStaff,
  onOpenDemoGuide,
  initialMode = 'report',
  initialTicketId = ''
}) => {
  const [activeTab, setActiveTab] = useState<'report' | 'track'>(initialMode);
  const [submittedTicket, setSubmittedTicket] = useState<Ticket | null>(null);
  const [ticketToTrack, setTicketToTrack] = useState<string>(initialTicketId);
  const [prefillScenario, setPrefillScenario] = useState<{
    building?: string;
    location?: string;
    description?: string;
  } | undefined>(undefined);

  const handleComplaintSubmitted = (ticket: Ticket) => {
    setSubmittedTicket(ticket);
  };

  const handleTrackTicket = (id: string) => {
    setSubmittedTicket(null);
    setTicketToTrack(id);
    setActiveTab('track');
  };

  const handleStartNewComplaint = () => {
    setSubmittedTicket(null);
    setPrefillScenario(undefined);
    setActiveTab('report');
  };

  const handleCategoryCardClick = (cat: TicketCategory) => {
    const examples: Record<TicketCategory, { b: string; l: string; d: string }> = {
      'Plumbing': {
        b: 'Science & Engineering Complex',
        l: '2nd Floor Restroom',
        d: 'Sink faucet is loose and leaking cold water continuously onto the floor.'
      },
      'Electricity': {
        b: 'Main Academic Quad',
        l: 'Lecture Hall 101, Row 4',
        d: 'Power outlet under the desk row has no power and breaker seems tripped.'
      },
      'Cleanliness': {
        b: 'Student Union Center',
        l: 'Food Court Stairwell',
        d: 'Large soda spill on the steps and recycling receptacle is overflowing.'
      },
      'Internet Connectivity': {
        b: 'University Memorial Library',
        l: '3rd Floor Quiet Study Wing',
        d: 'eduroam wireless keeps disconnecting every few minutes for multiple laptops.'
      }
    };

    setPrefillScenario({
      building: examples[cat].b,
      location: examples[cat].l,
      description: examples[cat].d
    });
    setSubmittedTicket(null);
    setActiveTab('report');
  };

  return (
    <div className="space-y-10 pb-12">
      {/* Hero Section */}
      <div className="relative rounded-3xl bg-gradient-to-b from-blue-900 via-indigo-950 to-slate-950 text-white overflow-hidden shadow-xl border border-blue-900/40">
        <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:16px_16px]" />

        <div className="relative max-w-5xl mx-auto px-6 py-12 sm:py-16 text-center space-y-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-500/20 border border-blue-400/30 text-blue-200 text-xs font-semibold backdrop-blur-md">
            <Sparkles size={14} className="text-blue-300" />
            <span>Campus Maintenance Powered by Gemini 3.8 Flash</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white max-w-3xl mx-auto leading-tight">
            Fixing Campus Facilities Faster with <span className="bg-gradient-to-r from-blue-400 to-sky-300 bg-clip-text text-transparent">AI-Assisted Triage</span>
          </h1>

          <p className="text-sm sm:text-base text-slate-300 max-w-2xl mx-auto leading-relaxed">
            Have a maintenance issue on campus? Submit in informal words. CampusConnect automatically categorizes, identifies missing details, routes to the right technicians, and keeps you updated.
          </p>

          {/* Quick Actions Mode Switcher */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              onClick={() => {
                setSubmittedTicket(null);
                setActiveTab('report');
              }}
              className={`px-5 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all cursor-pointer shadow-md ${
                activeTab === 'report' && !submittedTicket
                  ? 'bg-blue-600 text-white shadow-blue-500/30 ring-2 ring-blue-400'
                  : 'bg-white/10 hover:bg-white/15 text-slate-200 backdrop-blur-sm'
              }`}
            >
              Report New Issue
            </button>

            <button
              onClick={() => {
                setSubmittedTicket(null);
                setActiveTab('track');
              }}
              className={`px-5 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all cursor-pointer shadow-md ${
                activeTab === 'track'
                  ? 'bg-blue-600 text-white shadow-blue-500/30 ring-2 ring-blue-400'
                  : 'bg-white/10 hover:bg-white/15 text-slate-200 backdrop-blur-sm'
              }`}
            >
              Track Ticket by ID
            </button>

            <button
              onClick={onOpenDemoGuide}
              className="px-5 py-2.5 rounded-xl font-bold text-xs sm:text-sm bg-purple-600/30 hover:bg-purple-600/50 border border-purple-400/40 text-purple-200 transition-all cursor-pointer flex items-center gap-1.5"
            >
              <Sparkles size={14} className="text-purple-300" />
              <span>Interactive E2E Demo</span>
            </button>
          </div>
        </div>

        {/* 4 Supported Categories Banner */}
        <div className="relative border-t border-slate-800 bg-slate-950/70 p-4 sm:p-6">
          <div className="max-w-5xl mx-auto">
            <div className="text-center mb-3">
              <span className="text-[11px] uppercase font-bold tracking-wider text-slate-400">
                Click a category below to test a sample scenario:
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { cat: 'Plumbing' as TicketCategory, icon: Wrench, color: 'text-blue-400', border: 'hover:border-blue-500/40', desc: 'Leaks, faucets, drains, toilets' },
                { cat: 'Electricity' as TicketCategory, icon: Zap, color: 'text-amber-400', border: 'hover:border-amber-500/40', desc: 'Outlets, sparks, lights, breakers' },
                { cat: 'Cleanliness' as TicketCategory, icon: Sparkles, color: 'text-emerald-400', border: 'hover:border-emerald-500/40', desc: 'Spills, trash, sanitation, odors' },
                { cat: 'Internet Connectivity' as TicketCategory, icon: Wifi, color: 'text-indigo-400', border: 'hover:border-indigo-500/40', desc: 'Wi-Fi drops, APs, ethernet, slow LAN' },
              ].map(({ cat, icon: Icon, color, border, desc }) => (
                <button
                  key={cat}
                  onClick={() => handleCategoryCardClick(cat)}
                  className={`p-3 rounded-xl bg-slate-900/80 border border-slate-800 ${border} text-left transition-all hover:scale-[1.02] cursor-pointer group`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <Icon size={16} className={color} />
                    <span className="font-bold text-xs text-slate-200 group-hover:text-white">
                      {cat}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400 leading-tight">
                    {desc}
                  </p>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Main Body: Conditional View Render */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {submittedTicket ? (
          <TicketConfirmation
            ticket={submittedTicket}
            onTrackTicket={handleTrackTicket}
            onNewComplaint={handleStartNewComplaint}
          />
        ) : activeTab === 'report' ? (
          <ComplaintForm
            onSuccess={handleComplaintSubmitted}
            onNavigateToTrack={handleTrackTicket}
            prefillData={prefillScenario}
          />
        ) : (
          <TicketTracker
            initialTicketId={ticketToTrack}
            onNavigateToNewComplaint={handleStartNewComplaint}
          />
        )}
      </div>
    </div>
  );
};
