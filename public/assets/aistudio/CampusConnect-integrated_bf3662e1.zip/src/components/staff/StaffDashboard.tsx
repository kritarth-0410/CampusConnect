import React, { useState, useEffect, useMemo } from 'react';
import {
  Search,
  Filter,
  HardHat,
  RefreshCw,
  AlertTriangle,
  Building,
  User,
  ShieldCheck,
  Clock,
  Sparkles,
  ChevronRight,
  ExternalLink,
  ShieldAlert,
  Inbox,
  LayoutGrid,
  List,
  X,
  CheckCircle2,
  Wrench,
  Zap,
  Wifi,
  MapPin,
  Tag
} from 'lucide-react';
import {
  Ticket,
  TicketCategory,
  TicketStatus,
  Department,
  TICKET_CATEGORIES,
  TICKET_STATUSES,
  DEPARTMENTS,
  CATEGORY_DEPARTMENT_ROUTING
} from '../../shared/types.js';
import { CategoryBadge } from '../common/CategoryBadge.js';
import { StatusBadge } from '../common/StatusBadge.js';
import { StaffMetrics } from './StaffMetrics.js';
import { TicketDetailModal } from './TicketDetailModal.js';
import { apiClient } from '../../services/apiClient.js';
import { formatRelativeTime, formatFullDateTime } from './staffUtils.js';

const STAFF_ROLES = [
  'Sarah M. (Triage Supervisor)',
  'Carlos Rivera (Master Plumber)',
  'Marcus Vance (Senior Electrician)',
  'Elena Gomez (Custodial Lead)',
  'Maya Lin (Network NOC Engineer)'
];

interface StaffDashboardProps {
  onOpenDemoGuide: () => void;
}

export const StaffDashboard: React.FC<StaffDashboardProps> = ({ onOpenDemoGuide }) => {
  // Data state
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [stats, setStats] = useState({
    total: 0,
    submitted: 0,
    underReview: 0,
    assigned: 0,
    inProgress: 0,
    resolved: 0,
    byCategory: {
      'Plumbing': 0,
      'Electricity': 0,
      'Cleanliness': 0,
      'Internet Connectivity': 0
    }
  });

  // Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');
  const [departmentFilter, setDepartmentFilter] = useState<string>('ALL');
  const [buildingFilter, setBuildingFilter] = useState<string>('ALL');

  // UI display state
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('table');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [activeStaffRole, setActiveStaffRole] = useState(STAFF_ROLES[0]);
  const [feedbackToast, setFeedbackToast] = useState<{
    type: 'success' | 'info';
    message: string;
  } | null>(null);

  // Auto-dismiss toast
  useEffect(() => {
    if (feedbackToast) {
      const timer = setTimeout(() => setFeedbackToast(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [feedbackToast]);

  // Load tickets from server
  const fetchTickets = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const res = await apiClient.getTickets({
        query: searchQuery.trim() || undefined,
        status: statusFilter,
        category: categoryFilter,
        department: departmentFilter,
        building: buildingFilter
      });

      if (res.success) {
        setTickets(res.tickets);
        setStats(res.stats);
      } else {
        setError('Failed to load maintenance complaints from server.');
      }
    } catch (err: any) {
      setError(err.message || 'Error communicating with facilities server.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchTickets();
  }, [statusFilter, categoryFilter, departmentFilter, buildingFilter]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchTickets();
  };

  const handleClearSearch = () => {
    setSearchQuery('');
    // Trigger re-fetch with empty query
    setIsLoading(true);
    apiClient
      .getTickets({
        status: statusFilter,
        category: categoryFilter,
        department: departmentFilter,
        building: buildingFilter
      })
      .then((res) => {
        if (res.success) {
          setTickets(res.tickets);
          setStats(res.stats);
        }
      })
      .catch((err) => setError(err.message))
      .finally(() => setIsLoading(false));
  };

  const handleResetAllFilters = () => {
    setSearchQuery('');
    setStatusFilter('ALL');
    setCategoryFilter('ALL');
    setDepartmentFilter('ALL');
    setBuildingFilter('ALL');
  };

  const handleTicketUpdated = (updatedTicket: Ticket) => {
    setTickets((prev) =>
      prev.map((t) => (t.id === updatedTicket.id ? updatedTicket : t))
    );
    setSelectedTicket(updatedTicket);
    setFeedbackToast({
      type: 'success',
      message: `Ticket ${updatedTicket.id} updated (Status: ${updatedTicket.status})`
    });
    // Refresh stats from backend
    apiClient.getTickets().then((res) => {
      if (res.success) setStats(res.stats);
    });
  };

  // Active filter count
  const activeFiltersCount = useMemo(() => {
    let count = 0;
    if (searchQuery.trim()) count++;
    if (statusFilter !== 'ALL') count++;
    if (categoryFilter !== 'ALL') count++;
    if (departmentFilter !== 'ALL') count++;
    if (buildingFilter !== 'ALL') count++;
    return count;
  }, [searchQuery, statusFilter, categoryFilter, departmentFilter, buildingFilter]);

  // Duplicate warnings total count
  const duplicateWarningCount = tickets.reduce(
    (acc, t) => acc + (t.duplicateWarnings && t.duplicateWarnings.length > 0 ? 1 : 0),
    0
  );

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Toast Feedback Banner */}
      {feedbackToast && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-5 right-5 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl bg-slate-900 text-white shadow-xl text-xs font-semibold border border-slate-700 animate-in fade-in slide-in-from-bottom-3 duration-200"
        >
          <CheckCircle2 size={16} className="text-emerald-400 shrink-0" />
          <span>{feedbackToast.message}</span>
          <button
            onClick={() => setFeedbackToast(null)}
            className="ml-2 text-slate-400 hover:text-white"
            aria-label="Dismiss notification"
          >
            <X size={14} />
          </button>
        </div>
      )}

      {/* Explicit Simulated Staff Authentication Notice */}
      <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-300 text-amber-950 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs shadow-xs">
        <div className="flex items-start sm:items-center gap-2.5">
          <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0 mt-0.5 sm:mt-0" aria-hidden="true" />
          <div>
            <div className="font-bold flex items-center gap-1.5 flex-wrap">
              <span>Prototype Access: Simulated Staff Mode</span>
              <span className="text-[10px] font-normal px-2 py-0.5 rounded-full bg-amber-200 text-amber-900 font-mono">
                NON-SECURE DEMO ONLY
              </span>
            </div>
            <p className="text-amber-800 text-[11px] mt-0.5">
              Role-based simulation enabled for campus facilities evaluation. Production deployment connects to campus Single Sign-On (SSO / SAML).
            </p>
          </div>
        </div>

        {/* Staff Role Switcher */}
        <div className="flex items-center gap-2 shrink-0">
          <label htmlFor="staff-role-select" className="text-slate-600 font-medium">Acting As:</label>
          <select
            id="staff-role-select"
            value={activeStaffRole}
            onChange={(e) => setActiveStaffRole(e.target.value)}
            className="px-3 py-1.5 rounded-lg border border-amber-300 bg-white text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/20"
          >
            {STAFF_ROLES.map((r) => (
              <option key={r} value={r}>
                {r}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Top Header & Quick Actions */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <HardHat className="text-amber-500" aria-hidden="true" />
            <span>Facilities Dispatch &amp; Resolution Board</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            AI-prioritized complaints across campus buildings, department assignments, and resolution tracking.
          </p>
        </div>

        <div className="flex items-center gap-2 self-stretch sm:self-auto justify-end">
          {/* View toggle (desktop only) */}
          <div className="hidden sm:flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200">
            <button
              type="button"
              onClick={() => setViewMode('table')}
              aria-label="Table view"
              className={`p-1.5 rounded-md transition-colors ${
                viewMode === 'table' ? 'bg-white shadow-2xs text-slate-900' : 'text-slate-500 hover:text-slate-700'
              }`}
              title="Dense Table View"
            >
              <List size={16} />
            </button>
            <button
              type="button"
              onClick={() => setViewMode('cards')}
              aria-label="Cards view"
              className={`p-1.5 rounded-md transition-colors ${
                viewMode === 'cards' ? 'bg-white shadow-2xs text-slate-900' : 'text-slate-500 hover:text-slate-700'
              }`}
              title="Card View"
            >
              <LayoutGrid size={16} />
            </button>
          </div>

          <button
            onClick={fetchTickets}
            disabled={isLoading}
            aria-label="Refresh complaint list"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold shadow-2xs transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-blue-500"
          >
            <RefreshCw size={13} className={isLoading ? 'animate-spin' : ''} aria-hidden="true" />
            <span>Refresh</span>
          </button>

          <button
            onClick={onOpenDemoGuide}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-indigo-500"
          >
            <Sparkles size={13} aria-hidden="true" />
            <span>Demo Guide</span>
          </button>
        </div>
      </div>

      {/* Metrics Cards Strip */}
      <StaffMetrics
        stats={stats}
        duplicateCount={duplicateWarningCount}
        activeStatusFilter={statusFilter}
        onSelectStatusFilter={setStatusFilter}
      />

      {/* Comprehensive Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          {/* Search Input by ID or Keyword */}
          <form onSubmit={handleSearchSubmit} className="relative sm:col-span-2 lg:col-span-1">
            <label htmlFor="complaint-search-input" className="sr-only">
              Search complaints by Ticket ID, keyword, building or technician
            </label>
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" aria-hidden="true" />
            <input
              id="complaint-search-input"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by ID (e.g. CC-1001), room, keyword..."
              className="w-full pl-9 pr-16 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 text-slate-800 bg-slate-50/40 text-xs"
            />
            {searchQuery ? (
              <button
                type="button"
                onClick={handleClearSearch}
                aria-label="Clear search query"
                className="absolute right-12 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1"
              >
                <X size={13} />
              </button>
            ) : null}
            <button
              type="submit"
              className="absolute right-1.5 top-1/2 -translate-y-1/2 px-2.5 py-1 rounded-md bg-slate-100 hover:bg-slate-200 text-[11px] font-semibold text-slate-700 cursor-pointer transition-colors"
            >
              Search
            </button>
          </form>

          {/* Category Filter */}
          <div>
            <label htmlFor="category-filter-select" className="sr-only">Filter by category</label>
            <select
              id="category-filter-select"
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500/20 text-xs"
            >
              <option value="ALL">All Categories ({stats.total})</option>
              {TICKET_CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c} ({stats.byCategory[c] || 0})
                </option>
              ))}
            </select>
          </div>

          {/* Department Filter */}
          <div>
            <label htmlFor="department-filter-select" className="sr-only">Filter by responsible department</label>
            <select
              id="department-filter-select"
              value={departmentFilter}
              onChange={(e) => setDepartmentFilter(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500/20 text-xs"
            >
              <option value="ALL">All Departments</option>
              {DEPARTMENTS.map((dept) => (
                <option key={dept} value={dept}>
                  {dept.replace(' Department', '').replace(' Division', '').replace(' Services', '').replace(' Team', '')}
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <label htmlFor="status-filter-select" className="sr-only">Filter by complaint status</label>
            <select
              id="status-filter-select"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500/20 text-xs"
            >
              <option value="ALL">All Statuses ({stats.total})</option>
              {TICKET_STATUSES.map((st) => (
                <option key={st} value={st}>
                  {st}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Active Filters Row (if any active) */}
        {activeFiltersCount > 0 && (
          <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 text-xs">
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-slate-400 font-medium">Active filters:</span>
              {searchQuery && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 border border-blue-200 text-[11px] font-medium">
                  Query: "{searchQuery}"
                  <button onClick={handleClearSearch} className="hover:text-blue-900" aria-label="Remove search query filter">
                    <X size={11} />
                  </button>
                </span>
              )}
              {categoryFilter !== 'ALL' && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-700 border border-indigo-200 text-[11px] font-medium">
                  Category: {categoryFilter}
                  <button onClick={() => setCategoryFilter('ALL')} className="hover:text-indigo-900" aria-label="Remove category filter">
                    <X size={11} />
                  </button>
                </span>
              )}
              {departmentFilter !== 'ALL' && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-50 text-amber-800 border border-amber-200 text-[11px] font-medium">
                  Dept: {departmentFilter.split(' ')[0]}
                  <button onClick={() => setDepartmentFilter('ALL')} className="hover:text-amber-950" aria-label="Remove department filter">
                    <X size={11} />
                  </button>
                </span>
              )}
              {statusFilter !== 'ALL' && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-purple-50 text-purple-700 border border-purple-200 text-[11px] font-medium">
                  Status: {statusFilter}
                  <button onClick={() => setStatusFilter('ALL')} className="hover:text-purple-900" aria-label="Remove status filter">
                    <X size={11} />
                  </button>
                </span>
              )}
            </div>

            <button
              onClick={handleResetAllFilters}
              className="text-slate-500 hover:text-rose-600 font-semibold text-[11px] underline cursor-pointer"
            >
              Reset All Filters
            </button>
          </div>
        )}
      </div>

      {/* Complaints List Container */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {/* Loading Skeleton State */}
        {isLoading ? (
          <div className="p-8 space-y-4" aria-busy="true" aria-live="polite">
            <div className="flex items-center justify-center gap-2 text-blue-600 text-xs font-semibold py-4">
              <RefreshCw className="w-5 h-5 animate-spin" />
              <span>Loading campus facilities complaints...</span>
            </div>
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="animate-pulse flex items-center justify-between gap-4 p-4 border-b border-slate-100 last:border-none">
                <div className="space-y-2 w-1/4">
                  <div className="h-4 bg-slate-200 rounded-md w-20"></div>
                  <div className="h-3 bg-slate-100 rounded-md w-16"></div>
                </div>
                <div className="h-5 bg-slate-200 rounded-md w-24"></div>
                <div className="space-y-1.5 w-1/3">
                  <div className="h-4 bg-slate-200 rounded-md w-3/4"></div>
                  <div className="h-3 bg-slate-100 rounded-md w-1/2"></div>
                </div>
                <div className="h-6 bg-slate-200 rounded-md w-20"></div>
                <div className="h-8 bg-slate-200 rounded-lg w-16"></div>
              </div>
            ))}
          </div>
        ) : error ? (
          /* Error State */
          <div className="p-8 text-center space-y-3 text-rose-700 bg-rose-50/50" role="alert">
            <AlertTriangle className="w-7 h-7 mx-auto text-rose-600" aria-hidden="true" />
            <h4 className="text-sm font-bold">Facilities Connection Error</h4>
            <p className="text-xs text-rose-800 max-w-md mx-auto">{error}</p>
            <button
              onClick={fetchTickets}
              className="px-4 py-2 rounded-lg text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white cursor-pointer shadow-xs transition-colors"
            >
              Retry Connection
            </button>
          </div>
        ) : tickets.length === 0 ? (
          /* Empty State */
          <div className="p-12 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-400">
              <Inbox size={24} aria-hidden="true" />
            </div>
            <h4 className="text-base font-bold text-slate-800">No Complaints Match Your Filters</h4>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              There are currently no tickets matching your search query or selected criteria.
            </p>
            {activeFiltersCount > 0 ? (
              <button
                onClick={handleResetAllFilters}
                className="px-4 py-2 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white cursor-pointer transition-colors shadow-xs"
              >
                Reset All Active Filters
              </button>
            ) : null}
          </div>
        ) : (
          <>
            {/* View 1: Mobile Responsive Cards (Visible on mobile screens < 768px, or when viewMode === 'cards') */}
            <div className={`${viewMode === 'table' ? 'md:hidden' : ''} divide-y divide-slate-100`}>
              {tickets.map((t) => {
                const hasDuplicates = t.duplicateWarnings && t.duplicateWarnings.length > 0;
                const isHazard = t.aiAnalysis?.urgencyAssessment === 'Safety Hazard';

                return (
                  <article
                    key={t.id}
                    className="p-4 space-y-3 hover:bg-blue-50/30 transition-colors"
                  >
                    {/* Top Row: ID, Badges, Urgency */}
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono font-bold text-blue-700 text-sm">
                          {t.id}
                        </span>
                        <CategoryBadge category={t.category} size="sm" />
                        <StatusBadge status={t.status} size="sm" />
                        {isHazard && (
                          <span
                            title="Safety Hazard Flagged by Gemini AI"
                            className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 border border-rose-300"
                          >
                            <ShieldAlert size={11} />
                            <span>Hazard</span>
                          </span>
                        )}
                      </div>

                      <span className="text-[11px] text-slate-400 font-mono shrink-0">
                        {formatRelativeTime(t.createdAt)}
                      </span>
                    </div>

                    {/* Middle: Title & Location */}
                    <div>
                      <h3 className="font-semibold text-slate-900 text-sm line-clamp-2">
                        {t.title}
                      </h3>
                      <p className="text-xs text-slate-500 flex items-center gap-1 mt-1">
                        <Building size={12} className="shrink-0 text-slate-400" aria-hidden="true" />
                        <span className="truncate">{t.building} • {t.location}</span>
                      </p>
                    </div>

                    {/* Assignment & Flags */}
                    <div className="flex flex-wrap items-center justify-between gap-2 text-xs pt-2 border-t border-slate-100">
                      <div>
                        {t.assignment ? (
                          <span className="text-slate-600 text-[11px]">
                            Assigned: <strong className="text-slate-800">{t.assignment.assignedTo || t.assignment.department.split(' ')[0]}</strong>
                          </span>
                        ) : (
                          <span className="text-slate-400 text-[11px] italic">
                            Unassigned technician
                          </span>
                        )}
                      </div>

                      {hasDuplicates && (
                        <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300">
                          <AlertTriangle size={10} />
                          <span>Duplicate? ({t.duplicateWarnings!.length})</span>
                        </span>
                      )}
                    </div>

                    {/* Mobile Manage Button (Min touch target 44px) */}
                    <button
                      type="button"
                      onClick={() => setSelectedTicket(t)}
                      aria-label={`Manage complaint ${t.id}: ${t.title}`}
                      className="w-full py-2.5 px-4 rounded-xl text-xs font-bold bg-slate-900 hover:bg-blue-600 text-white transition-colors cursor-pointer flex items-center justify-center gap-2 shadow-2xs"
                    >
                      <span>Manage Complaint</span>
                      <ChevronRight size={14} />
                    </button>
                  </article>
                );
              })}
            </div>

            {/* View 2: High-Density Desktop Data Grid (Hidden on mobile if viewMode === 'table') */}
            <div className={`hidden ${viewMode === 'table' ? 'md:block' : 'hidden'} overflow-x-auto`}>
              <table className="w-full text-left text-xs divide-y divide-slate-200">
                <thead className="bg-slate-50 text-slate-500 font-semibold uppercase tracking-wider text-[10px]">
                  <tr>
                    <th scope="col" className="px-4 py-3">Ticket ID</th>
                    <th scope="col" className="px-4 py-3">Category</th>
                    <th scope="col" className="px-4 py-3">Issue Summary &amp; Location</th>
                    <th scope="col" className="px-4 py-3">Status</th>
                    <th scope="col" className="px-4 py-3">Assigned Dept / Tech</th>
                    <th scope="col" className="px-4 py-3">Submitted</th>
                    <th scope="col" className="px-4 py-3">Flags</th>
                    <th scope="col" className="px-4 py-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {tickets.map((t) => {
                    const hasDuplicates = t.duplicateWarnings && t.duplicateWarnings.length > 0;
                    const isHazard = t.aiAnalysis?.urgencyAssessment === 'Safety Hazard';

                    return (
                      <tr
                        key={t.id}
                        className="hover:bg-blue-50/40 transition-colors group cursor-pointer"
                        onClick={() => setSelectedTicket(t)}
                      >
                        {/* ID & Urgency */}
                        <td className="px-4 py-3.5 whitespace-nowrap">
                          <div className="flex items-center gap-1.5">
                            <span className="font-mono font-bold text-blue-700 text-sm tabular-nums">
                              {t.id}
                            </span>
                            {isHazard && (
                              <span
                                title="Safety Hazard Flagged by Gemini AI"
                                className="w-2 h-2 rounded-full bg-rose-500 animate-pulse"
                                aria-label="Safety hazard"
                              />
                            )}
                          </div>
                          {t.aiAnalysis?.urgencyAssessment && (
                            <span className="text-[10px] text-slate-400 block font-medium">
                              {t.aiAnalysis.urgencyAssessment}
                            </span>
                          )}
                        </td>

                        {/* Category */}
                        <td className="px-4 py-3.5 whitespace-nowrap">
                          <CategoryBadge category={t.category} size="sm" />
                        </td>

                        {/* Summary & Location */}
                        <td className="px-4 py-3.5 max-w-xs">
                          <p className="font-semibold text-slate-900 truncate">
                            {t.title}
                          </p>
                          <p className="text-[11px] text-slate-500 truncate flex items-center gap-1 mt-0.5">
                            <Building size={11} className="shrink-0 text-slate-400" aria-hidden="true" />
                            <span>{t.building} • {t.location}</span>
                          </p>
                        </td>

                        {/* Status */}
                        <td className="px-4 py-3.5 whitespace-nowrap">
                          <StatusBadge status={t.status} size="sm" />
                        </td>

                        {/* Assignment */}
                        <td className="px-4 py-3.5 max-w-[190px]">
                          {t.assignment ? (
                            <div>
                              <span className="font-medium text-slate-800 text-[11px] truncate block">
                                {t.assignment.department.replace(' Department', '').replace(' Services', '').replace(' Team', '')}
                              </span>
                              <span className="text-[10px] text-blue-600 truncate block">
                                {t.assignment.assignedTo || 'Unassigned Tech'}
                              </span>
                            </div>
                          ) : (
                            <span className="text-slate-400 text-[11px] italic">
                              Unassigned
                            </span>
                          )}
                        </td>

                        {/* Submission Time */}
                        <td className="px-4 py-3.5 whitespace-nowrap" title={formatFullDateTime(t.createdAt)}>
                          <span className="text-slate-700 font-medium text-[11px] block">
                            {formatRelativeTime(t.createdAt)}
                          </span>
                          <span className="text-[10px] text-slate-400 block font-mono">
                            {new Date(t.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </td>

                        {/* Warnings / Duplicate Flags */}
                        <td className="px-4 py-3.5 whitespace-nowrap">
                          {hasDuplicates ? (
                            <span
                              title="Duplicate Warning: Review against existing complaints"
                              className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300"
                            >
                              <AlertTriangle size={11} aria-hidden="true" />
                              <span>Duplicate? ({t.duplicateWarnings!.length})</span>
                            </span>
                          ) : (
                            <span className="text-slate-300 text-[11px]">—</span>
                          )}
                        </td>

                        {/* Action */}
                        <td className="px-4 py-3.5 text-right whitespace-nowrap">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedTicket(t);
                            }}
                            aria-label={`Manage ticket ${t.id}`}
                            className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 hover:bg-blue-600 hover:text-white text-slate-700 transition-colors shadow-2xs focus-visible:ring-2 focus-visible:ring-blue-500"
                          >
                            Manage
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>

      {/* Ticket Details Modal */}
      {selectedTicket && (
        <TicketDetailModal
          ticket={selectedTicket}
          activeStaffRole={activeStaffRole}
          onClose={() => setSelectedTicket(null)}
          onTicketUpdated={handleTicketUpdated}
          onNavigateToTicket={(id) => {
            const found = tickets.find((t) => t.id === id);
            if (found) {
              setSelectedTicket(found);
            } else {
              apiClient.getTicketById(id).then((res) => {
                if (res.ticket) setSelectedTicket(res.ticket);
              });
            }
          }}
        />
      )}
    </div>
  );
};
