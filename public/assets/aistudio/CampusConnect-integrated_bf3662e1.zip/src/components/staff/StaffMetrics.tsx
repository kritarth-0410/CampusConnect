import React from 'react';
import {
  Inbox,
  Eye,
  UserCheck,
  PlayCircle,
  CheckCircle2,
  AlertTriangle,
  Layers
} from 'lucide-react';
import { TicketCategory, TicketStatus } from '../../shared/types.js';

interface StaffMetricsProps {
  stats: {
    total: number;
    submitted: number;
    underReview: number;
    assigned: number;
    inProgress: number;
    resolved: number;
    byCategory: Record<TicketCategory, number>;
  };
  duplicateCount: number;
  activeStatusFilter: string;
  onSelectStatusFilter: (status: string) => void;
}

export const StaffMetrics: React.FC<StaffMetricsProps> = ({
  stats,
  duplicateCount,
  activeStatusFilter,
  onSelectStatusFilter
}) => {
  const cards = [
    {
      label: 'All Tickets',
      value: stats.total,
      filter: 'ALL',
      icon: Layers,
      color: 'text-slate-700 bg-slate-100/90 border-slate-200 hover:bg-slate-200/70',
      activeBorder: 'ring-2 ring-slate-900 border-slate-900'
    },
    {
      label: 'Submitted',
      value: stats.submitted,
      filter: 'Submitted',
      icon: Inbox,
      color: 'text-blue-700 bg-blue-50/80 border-blue-200 hover:bg-blue-100/80',
      activeBorder: 'ring-2 ring-blue-600 border-blue-600'
    },
    {
      label: 'Under Review',
      value: stats.underReview,
      filter: 'Under Review',
      icon: Eye,
      color: 'text-purple-700 bg-purple-50/80 border-purple-200 hover:bg-purple-100/80',
      activeBorder: 'ring-2 ring-purple-600 border-purple-600'
    },
    {
      label: 'Assigned',
      value: stats.assigned,
      filter: 'Assigned',
      icon: UserCheck,
      color: 'text-sky-700 bg-sky-50/80 border-sky-200 hover:bg-sky-100/80',
      activeBorder: 'ring-2 ring-sky-600 border-sky-600'
    },
    {
      label: 'In Progress',
      value: stats.inProgress,
      filter: 'In Progress',
      icon: PlayCircle,
      color: 'text-amber-800 bg-amber-50/80 border-amber-300 hover:bg-amber-100/80',
      activeBorder: 'ring-2 ring-amber-600 border-amber-600'
    },
    {
      label: 'Resolved',
      value: stats.resolved,
      filter: 'Resolved',
      icon: CheckCircle2,
      color: 'text-emerald-800 bg-emerald-50/80 border-emerald-300 hover:bg-emerald-100/80',
      activeBorder: 'ring-2 ring-emerald-600 border-emerald-600'
    }
  ];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
      {cards.map((c) => {
        const Icon = c.icon;
        const isActive = activeStatusFilter === c.filter;

        return (
          <button
            type="button"
            key={c.label}
            onClick={() => onSelectStatusFilter(c.filter)}
            aria-pressed={isActive}
            aria-label={`Filter by ${c.label} (${c.value} tickets)`}
            className={`p-3 rounded-xl border text-left transition-all cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${c.color} ${
              isActive
                ? `${c.activeBorder} shadow-xs font-semibold scale-[1.01]`
                : 'opacity-95 hover:opacity-100 hover:shadow-2xs'
            }`}
          >
            <div className="flex items-center justify-between gap-1 mb-1">
              <span className="text-[11px] font-semibold text-slate-700 truncate">{c.label}</span>
              <Icon size={14} className="shrink-0 text-slate-500" aria-hidden="true" />
            </div>
            <div className="text-xl sm:text-2xl font-black tracking-tight text-slate-900 font-mono tabular-nums">
              {c.value}
            </div>
          </button>
        );
      })}
    </div>
  );
};
