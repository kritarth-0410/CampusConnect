import React, { useState, useEffect } from 'react';
import {
  X,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Sparkles,
  HardHat,
  User,
  ShieldAlert,
  Send,
  ArrowRight,
  FileText,
  MapPin,
  ExternalLink,
  Layers,
  HelpCircle,
  Copy,
  Check,
  Maximize2,
  ZoomIn,
  Building,
  Mail,
  UserCheck
} from 'lucide-react';
import {
  Ticket,
  TicketStatus,
  TICKET_STATUSES,
  DEPARTMENTS,
  Department,
  CATEGORY_DEPARTMENT_ROUTING
} from '../../shared/types.js';
import { CategoryBadge } from '../common/CategoryBadge.js';
import { StatusBadge } from '../common/StatusBadge.js';
import { apiClient } from '../../services/apiClient.js';
import { DEPARTMENT_TECHNICIANS, formatFullDateTime } from './staffUtils.js';

interface TicketDetailModalProps {
  ticket: Ticket;
  activeStaffRole: string;
  onClose: () => void;
  onTicketUpdated: (updatedTicket: Ticket) => void;
  onNavigateToTicket: (ticketId: string) => void;
}

export const TicketDetailModal: React.FC<TicketDetailModalProps> = ({
  ticket,
  activeStaffRole,
  onClose,
  onTicketUpdated,
  onNavigateToTicket
}) => {
  // Status update state
  const [selectedStatus, setSelectedStatus] = useState<TicketStatus>(ticket.status);
  const [statusNote, setStatusNote] = useState('');
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);
  const [statusError, setStatusError] = useState<string | null>(null);
  const [statusSuccess, setStatusSuccess] = useState<string | null>(null);

  // Assignment state
  const [assignDept, setAssignDept] = useState<Department>(
    ticket.assignment?.department || ticket.aiAnalysis?.recommendedDepartment || CATEGORY_DEPARTMENT_ROUTING[ticket.category]
  );
  const [technicianName, setTechnicianName] = useState(ticket.assignment?.assignedTo || '');
  const [priority, setPriority] = useState<'Low' | 'Medium' | 'High' | 'Emergency'>(
    ticket.assignment?.priority || (ticket.aiAnalysis?.urgencyAssessment === 'Safety Hazard' ? 'Emergency' : 'Medium')
  );
  const [assignNotes, setAssignNotes] = useState(ticket.assignment?.notes || '');
  const [isAssigning, setIsAssigning] = useState(false);
  const [assignSuccess, setAssignSuccess] = useState<string | null>(null);
  const [assignError, setAssignError] = useState<string | null>(null);

  // Photo Lightbox state
  const [isPhotoLightboxOpen, setIsPhotoLightboxOpen] = useState(false);

  // Copy Ticket ID state
  const [hasCopiedId, setHasCopiedId] = useState(false);

  // Listen for Escape key to close modal
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (isPhotoLightboxOpen) {
          setIsPhotoLightboxOpen(false);
        } else {
          onClose();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPhotoLightboxOpen, onClose]);

  // Handle Copy ID
  const handleCopyId = () => {
    navigator.clipboard.writeText(ticket.id).then(() => {
      setHasCopiedId(true);
      setTimeout(() => setHasCopiedId(false), 2500);
    });
  };

  // Quick apply AI suggested department
  const handleApplyAiSuggestion = () => {
    const suggested = ticket.aiAnalysis?.recommendedDepartment || CATEGORY_DEPARTMENT_ROUTING[ticket.category];
    if (suggested) {
      setAssignDept(suggested);
      // Pick first technician from presets if empty
      const presets = DEPARTMENT_TECHNICIANS[suggested];
      if (presets && presets.length > 0 && !technicianName) {
        setTechnicianName(presets[0]);
      }
    }
  };

  // Handle status update
  const handleUpdateStatus = async (newStatus: TicketStatus) => {
    setIsUpdatingStatus(true);
    setStatusError(null);
    setStatusSuccess(null);

    try {
      const res = await apiClient.updateStatus(ticket.id, {
        status: newStatus,
        notes: statusNote.trim() || `Status moved to ${newStatus} by ${activeStaffRole}`,
        changedBy: activeStaffRole
      });

      if (res.success && res.ticket) {
        setSelectedStatus(newStatus);
        setStatusNote('');
        setStatusSuccess(`Status successfully updated to "${newStatus}"`);
        onTicketUpdated(res.ticket);
        setTimeout(() => setStatusSuccess(null), 3500);
      } else {
        setStatusError('Failed to update ticket status on server.');
      }
    } catch (err: any) {
      setStatusError(err.message || 'Error communicating with facilities server.');
    } finally {
      setIsUpdatingStatus(false);
    }
  };

  // Handle assignment
  const handleAssign = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsAssigning(true);
    setAssignError(null);
    setAssignSuccess(null);

    try {
      const res = await apiClient.assignTicket(ticket.id, {
        department: assignDept,
        assignedTo: technicianName.trim() || undefined,
        priority,
        notes: assignNotes.trim() || undefined,
        assignedBy: activeStaffRole
      });

      if (res.success && res.ticket) {
        setAssignSuccess(`Ticket assigned to ${assignDept}${technicianName ? ` (${technicianName})` : ''}`);
        onTicketUpdated(res.ticket);
        setTimeout(() => setAssignSuccess(null), 3500);
      } else {
        setAssignError('Failed to save assignment to ticket server.');
      }
    } catch (err: any) {
      setAssignError(err.message || 'Error saving assignment.');
    } finally {
      setIsAssigning(false);
    }
  };

  // Suggested technicians for selected department
  const suggestedTechs = DEPARTMENT_TECHNICIANS[assignDept] || [];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="ticket-modal-title"
      className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6"
    >
      <div
        className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-4xl w-full max-h-[92vh] flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between gap-4 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3 flex-wrap">
            <div className="flex items-center gap-1.5">
              <span className="font-mono text-xl font-extrabold text-blue-400 tabular-nums">
                {ticket.id}
              </span>
              <button
                type="button"
                onClick={handleCopyId}
                aria-label="Copy ticket ID to clipboard"
                className="p-1 rounded text-slate-400 hover:text-white transition-colors"
                title="Copy Ticket ID"
              >
                {hasCopiedId ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
              </button>
            </div>
            <StatusBadge status={ticket.status} size="sm" />
            <CategoryBadge category={ticket.category} size="sm" />
            {ticket.aiAnalysis?.urgencyAssessment === 'Safety Hazard' && (
              <span className="text-xs font-bold px-2 py-0.5 rounded-md bg-rose-500/20 text-rose-300 border border-rose-500/30 flex items-center gap-1">
                <ShieldAlert size={12} />
                <span>Safety Hazard</span>
              </span>
            )}
          </div>

          <button
            onClick={onClose}
            aria-label="Close complaint details"
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-blue-400"
          >
            <X size={18} />
          </button>
        </div>

        {/* Modal Content Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-slate-800 text-sm">
          {/* Title & Metadata */}
          <div className="space-y-1.5">
            <h3 id="ticket-modal-title" className="text-xl font-bold text-slate-950">
              {ticket.title}
            </h3>
            <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500">
              <span className="flex items-center gap-1">
                <MapPin size={13} className="text-blue-600 shrink-0" aria-hidden="true" />
                <strong>{ticket.building}</strong> • {ticket.location}
              </span>
              <span>•</span>
              <span className="flex items-center gap-1 font-mono">
                <Clock size={13} aria-hidden="true" />
                Reported {formatFullDateTime(ticket.createdAt)}
              </span>
              {ticket.studentName && (
                <>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <User size={13} aria-hidden="true" />
                    Student: <strong>{ticket.studentName}</strong>
                    {ticket.studentEmail && <span className="text-slate-400">({ticket.studentEmail})</span>}
                  </span>
                </>
              )}
            </div>
          </div>

          {/* AI Analysis & Urgency Banner */}
          {ticket.aiAnalysis && (
            <div className="p-4 rounded-xl bg-indigo-50/70 border border-indigo-200 space-y-3">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-2">
                  <Sparkles size={16} className="text-indigo-600 shrink-0" aria-hidden="true" />
                  <span className="text-xs font-bold uppercase tracking-wider text-indigo-950">
                    Gemini AI Triage Assessment
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-medium px-2 py-0.5 rounded-md bg-indigo-100 text-indigo-800">
                    Confidence: {ticket.aiAnalysis.confidence} ({Math.round(ticket.aiAnalysis.confidenceScore * 100)}%)
                  </span>
                  {ticket.aiAnalysis.urgencyAssessment && (
                    <span className="text-xs font-bold px-2 py-0.5 rounded-md bg-slate-200/80 text-slate-800">
                      Urgency: {ticket.aiAnalysis.urgencyAssessment}
                    </span>
                  )}
                </div>
              </div>

              <div className="text-xs space-y-1">
                <span className="text-slate-500 font-medium">Problem Summary:</span>
                <p className="text-slate-900 font-semibold text-sm">
                  "{ticket.aiAnalysis.conciseSummary}"
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-1 border-t border-indigo-100 text-slate-600">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-slate-400">Suggested Dept: </span>
                    <span className="font-semibold text-slate-800">{ticket.aiAnalysis.recommendedDepartment}</span>
                  </div>
                  {assignDept !== ticket.aiAnalysis.recommendedDepartment && (
                    <button
                      type="button"
                      onClick={handleApplyAiSuggestion}
                      className="text-[11px] font-semibold text-indigo-700 hover:text-indigo-900 underline ml-2"
                    >
                      Quick-Apply
                    </button>
                  )}
                </div>
                <div>
                  <span className="text-slate-400">Category Assessed: </span>
                  <span className="font-semibold text-slate-800">{ticket.aiAnalysis.suggestedCategory}</span>
                </div>
              </div>

              {/* Missing Details Identified by AI */}
              {ticket.aiAnalysis.missingDetailsIdentified.length > 0 && (
                <div className="pt-2 border-t border-indigo-100">
                  <span className="text-slate-500 font-medium block mb-1 text-xs">
                    Missing details flagged by triage:
                  </span>
                  <ul className="list-disc list-inside space-y-0.5 text-xs text-slate-700">
                    {ticket.aiAnalysis.missingDetailsIdentified.map((m, i) => (
                      <li key={i}>{m}</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Student Clarification Answers if replied */}
              {ticket.studentFollowUpAnswers && Object.keys(ticket.studentFollowUpAnswers).length > 0 && (
                <div className="pt-2 border-t border-indigo-100 space-y-1">
                  <span className="text-indigo-900 font-bold block text-xs">
                    Student Follow-Up Answers Provided:
                  </span>
                  <div className="space-y-1 text-xs bg-white p-2.5 rounded-lg border border-indigo-100">
                    {Object.entries(ticket.studentFollowUpAnswers).map(([q, a], idx) => (
                      <div key={idx}>
                        <span className="text-slate-500">{q}:</span>{' '}
                        <strong className="text-slate-800">{a}</strong>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Duplicate Warnings Panel (Human Review Warning) */}
          {ticket.duplicateWarnings && ticket.duplicateWarnings.length > 0 && (
            <div className="p-4 rounded-xl bg-amber-50 border border-amber-300 text-amber-900 space-y-2">
              <div className="flex items-start gap-2">
                <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" aria-hidden="true" />
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-950">
                    Possible Duplicate Complaint Detected ({ticket.duplicateWarnings.length})
                  </h4>
                  <p className="text-xs text-amber-800 mt-0.5">
                    <strong>Staff Review Rule:</strong> Duplicate matches are provided as advisory warnings for staff evaluation. Complaints are never automatically rejected or merged.
                  </p>
                </div>
              </div>

              <div className="space-y-2 pl-0 sm:pl-7 pt-1">
                {ticket.duplicateWarnings.map((dup) => (
                  <div
                    key={dup.ticketId}
                    className="p-3 rounded-lg bg-white border border-amber-200 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs"
                  >
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono font-bold text-blue-700">{dup.ticketId}</span>
                        <StatusBadge status={dup.status} size="sm" />
                        <span className="font-semibold text-slate-800">{dup.title}</span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-1">
                        Location: {dup.location} • Match reason: {dup.matchReason} (Similarity: {Math.round(dup.similarityScore * 100)}%)
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => onNavigateToTicket(dup.ticketId)}
                      aria-label={`Inspect candidate duplicate ticket ${dup.ticketId}`}
                      className="px-3 py-1.5 rounded-md text-xs font-semibold bg-amber-100 hover:bg-amber-200 text-amber-950 transition-colors flex items-center justify-center gap-1 shrink-0 self-start sm:self-auto cursor-pointer"
                    >
                      <span>Inspect {dup.ticketId}</span>
                      <ExternalLink size={12} aria-hidden="true" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Description & Photo Section */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Original Student Report
            </h4>
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-slate-800 whitespace-pre-line leading-relaxed font-normal text-xs sm:text-sm">
              {ticket.description}
            </div>

            {/* Photo Evidence with Lightbox */}
            {(ticket.imageDataUri || ticket.imageUrl) && (
              <div className="pt-2">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
                  Attached Photo Evidence (Click to enlarge)
                </span>
                <div className="relative inline-block group">
                  <img
                    src={ticket.imageDataUri || ticket.imageUrl}
                    alt={`Photo evidence for complaint ${ticket.id} in ${ticket.building}`}
                    onClick={() => setIsPhotoLightboxOpen(true)}
                    className="max-h-64 rounded-xl border border-slate-300 object-cover cursor-pointer hover:opacity-95 transition-opacity"
                  />
                  <button
                    type="button"
                    onClick={() => setIsPhotoLightboxOpen(true)}
                    className="absolute bottom-2 right-2 px-2.5 py-1 rounded-md bg-slate-900/80 text-white text-[11px] font-semibold flex items-center gap-1 backdrop-blur-xs hover:bg-slate-900 transition-colors"
                  >
                    <Maximize2 size={12} />
                    <span>Expand</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Fullscreen Photo Lightbox Modal */}
          {isPhotoLightboxOpen && (ticket.imageDataUri || ticket.imageUrl) && (
            <div
              className="fixed inset-0 z-60 bg-black/80 flex items-center justify-center p-4 backdrop-blur-xs"
              onClick={() => setIsPhotoLightboxOpen(false)}
            >
              <div className="relative max-w-4xl max-h-[90vh]" onClick={(e) => e.stopPropagation()}>
                <img
                  src={ticket.imageDataUri || ticket.imageUrl}
                  alt="High-resolution complaint attachment"
                  className="max-h-[85vh] max-w-full rounded-xl object-contain shadow-2xl"
                />
                <button
                  type="button"
                  onClick={() => setIsPhotoLightboxOpen(false)}
                  className="absolute -top-3 -right-3 p-2 rounded-full bg-white text-slate-900 shadow-lg hover:bg-slate-100 cursor-pointer"
                  aria-label="Close photo preview"
                >
                  <X size={18} />
                </button>
              </div>
            </div>
          )}

          {/* Status Workflow Controls */}
          <div className="p-5 rounded-xl bg-slate-100 border border-slate-200 space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                <Layers size={15} aria-hidden="true" />
                <span>Status Workflow Progression</span>
              </h4>
              <span className="text-xs text-slate-500">
                Current Status: <strong className="text-slate-800">{ticket.status}</strong>
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {TICKET_STATUSES.map((st) => {
                const isCurrent = ticket.status === st;
                return (
                  <button
                    type="button"
                    key={st}
                    onClick={() => handleUpdateStatus(st)}
                    disabled={isUpdatingStatus || isCurrent}
                    aria-pressed={isCurrent}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer focus-visible:ring-2 focus-visible:ring-blue-500 ${
                      isCurrent
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 hover:border-slate-400'
                    } disabled:opacity-60`}
                  >
                    {isCurrent ? `✓ ${st}` : `Move to ${st}`}
                  </button>
                );
              })}
            </div>

            <div className="flex items-center gap-2 pt-1">
              <input
                type="text"
                value={statusNote}
                onChange={(e) => setStatusNote(e.target.value)}
                placeholder="Optional transition note for audit log (e.g. 'Inspected on site, valve replaced')"
                className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 bg-white"
              />
            </div>

            {statusSuccess && (
              <p className="text-xs text-emerald-700 bg-emerald-50 p-2 rounded-md border border-emerald-200" role="status">
                {statusSuccess}
              </p>
            )}

            {statusError && (
              <p className="text-xs text-rose-600 font-medium" role="alert">
                {statusError}
              </p>
            )}
          </div>

          {/* Department & Staff Assignment Controls */}
          <form onSubmit={handleAssign} className="p-5 rounded-xl bg-slate-50 border border-slate-200 space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                <HardHat size={15} className="text-amber-600" aria-hidden="true" />
                <span>Department &amp; Technician Assignment</span>
              </h4>
              {ticket.assignment && (
                <span className="text-xs text-slate-500">
                  Last assigned: <strong>{ticket.assignment.assignedBy}</strong>
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  Responsible Department
                </label>
                <select
                  value={assignDept}
                  onChange={(e) => setAssignDept(e.target.value as Department)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-slate-800 font-medium text-xs focus:ring-2 focus:ring-blue-500/20"
                >
                  {DEPARTMENTS.map((dept) => (
                    <option key={dept} value={dept}>
                      {dept}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  Assign Technician / Officer
                </label>
                <input
                  type="text"
                  list="suggested-technicians"
                  value={technicianName}
                  onChange={(e) => setTechnicianName(e.target.value)}
                  placeholder="e.g. Carlos Rivera or select preset"
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-slate-800 text-xs focus:ring-2 focus:ring-blue-500/20"
                />
                <datalist id="suggested-technicians">
                  {suggestedTechs.map((tech) => (
                    <option key={tech} value={tech} />
                  ))}
                </datalist>
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  Priority Rating
                </label>
                <select
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-slate-800 font-medium text-xs focus:ring-2 focus:ring-blue-500/20"
                >
                  <option value="Low">Low (Routine maintenance)</option>
                  <option value="Medium">Medium (Standard SLA 24h)</option>
                  <option value="High">High (Impacting classes/study)</option>
                  <option value="Emergency">Emergency (Immediate hazard)</option>
                </select>
              </div>
            </div>

            {/* Quick-Pick Tech Pills */}
            {suggestedTechs.length > 0 && (
              <div className="flex flex-wrap items-center gap-1.5 text-[11px] pt-1">
                <span className="text-slate-400 font-medium">Quick pick certified tech:</span>
                {suggestedTechs.map((t) => (
                  <button
                    type="button"
                    key={t}
                    onClick={() => setTechnicianName(t)}
                    className="px-2 py-0.5 rounded-md bg-slate-200/80 hover:bg-slate-300 text-slate-700 transition-colors cursor-pointer"
                  >
                    {t.split(' ')[0]} ({t.includes('Plumber') ? 'Plumber' : t.includes('Electrician') ? 'Electrician' : t.includes('Custodial') ? 'Lead' : 'NOC'})
                  </button>
                ))}
              </div>
            )}

            <div>
              <label className="block text-slate-600 font-semibold mb-1 text-xs">
                Internal Dispatch Notes
              </label>
              <input
                type="text"
                value={assignNotes}
                onChange={(e) => setAssignNotes(e.target.value)}
                placeholder="e.g. Bring replacement breaker switch and multimeter."
                className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 bg-white text-slate-800 focus:ring-2 focus:ring-blue-500/20"
              />
            </div>

            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pt-1">
              <span className="text-[11px] text-slate-500">
                Saving assignment will auto-advance complaint status to <strong>Assigned</strong> if currently Submitted or Under Review.
              </span>
              <button
                type="submit"
                disabled={isAssigning}
                className="w-full sm:w-auto px-4 py-2 rounded-lg text-xs font-bold bg-slate-900 hover:bg-slate-800 text-white cursor-pointer transition-colors shadow-xs focus-visible:ring-2 focus-visible:ring-blue-500"
              >
                {isAssigning ? 'Saving Assignment...' : 'Save Department Assignment'}
              </button>
            </div>

            {assignSuccess && (
              <p className="text-xs text-emerald-700 bg-emerald-50 p-2.5 rounded-md border border-emerald-200 flex items-center gap-2" role="status">
                <CheckCircle2 size={14} className="text-emerald-600 shrink-0" />
                <span>{assignSuccess}</span>
              </p>
            )}
            {assignError && (
              <p className="text-xs text-rose-700 bg-rose-50 p-2.5 rounded-md border border-rose-200" role="alert">
                {assignError}
              </p>
            )}
          </form>

          {/* Audit History Log */}
          <div className="space-y-3 pt-2">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <Clock size={14} aria-hidden="true" />
              <span>Chronological Status History Audit Trail</span>
            </h4>

            <div className="space-y-2">
              {ticket.statusHistory.map((h, i) => (
                <div
                  key={h.id || i}
                  className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-1.5"
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-slate-900">
                        {h.fromStatus ? `${h.fromStatus} → ` : ''}
                        <span className="text-blue-700 font-bold">{h.toStatus}</span>
                      </span>
                      <span className="text-slate-400">•</span>
                      <span className="text-slate-600 font-medium">{h.changedBy}</span>
                    </div>
                    {h.notes && <p className="text-slate-600 italic">"{h.notes}"</p>}
                  </div>
                  <span className="font-mono text-slate-400 text-[11px] shrink-0">
                    {formatFullDateTime(h.changedAt)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500 shrink-0">
          <span>Active Staff Identity: <strong>{activeStaffRole}</strong></span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg border border-slate-300 hover:bg-slate-100 font-semibold text-slate-700 cursor-pointer focus-visible:ring-2 focus-visible:ring-blue-500"
          >
            Close Details
          </button>
        </div>
      </div>
    </div>
  );
};
