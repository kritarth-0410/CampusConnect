import React from 'react';
import { Building2, ShieldCheck, Heart, Wrench, Zap, Sparkles, Wifi } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 text-slate-400 text-xs border-t border-slate-800 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Col 1: About */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-white font-bold text-base">
              <div className="w-6 h-6 rounded-md bg-blue-600 flex items-center justify-center text-white text-xs">
                <Building2 size={14} />
              </div>
              <span>CampusConnect</span>
            </div>
            <p className="text-slate-400 text-xs leading-relaxed">
              Empowering students and campus facilities staff through AI-assisted maintenance complaint triage, automated routing, and transparent status tracking.
            </p>
            <div className="flex items-center gap-1.5 text-emerald-400 text-[11px]">
              <ShieldCheck size={14} />
              <span>Full-Stack MVP with Gemini 3.8 Flash</span>
            </div>
          </div>

          {/* Col 2: The 4 Categories */}
          <div>
            <h4 className="text-white font-semibold text-xs tracking-wider uppercase mb-3">
              Supported Complaint Categories
            </h4>
            <ul className="space-y-2">
              <li className="flex items-center gap-2">
                <Wrench size={13} className="text-blue-400" />
                <span>Plumbing (Pipes, leaks, restroom fixtures)</span>
              </li>
              <li className="flex items-center gap-2">
                <Zap size={13} className="text-amber-400" />
                <span>Electricity (Outlets, lighting, breakers)</span>
              </li>
              <li className="flex items-center gap-2">
                <Sparkles size={13} className="text-emerald-400" />
                <span>Cleanliness (Spills, sanitation, waste)</span>
              </li>
              <li className="flex items-center gap-2">
                <Wifi size={13} className="text-indigo-400" />
                <span>Internet Connectivity (Wi-Fi, APs, LAN)</span>
              </li>
            </ul>
          </div>

          {/* Col 3: Collaboration Architecture */}
          <div>
            <h4 className="text-white font-semibold text-xs tracking-wider uppercase mb-3">
              4-Person Team Roles
            </h4>
            <ul className="space-y-1.5 text-[11px]">
              <li><strong className="text-slate-200">Person 1:</strong> Main App, Student Portal &amp; Coordinator</li>
              <li><strong className="text-slate-200">Person 2:</strong> Gemini AI Service &amp; Multimodal Triage</li>
              <li><strong className="text-slate-200">Person 3:</strong> Backend APIs, File Store &amp; Auditing</li>
              <li><strong className="text-slate-200">Person 4:</strong> Staff Dashboard, UX &amp; E2E Pitch</li>
            </ul>
          </div>

          {/* Col 4: Facility Policy & Emergency */}
          <div>
            <h4 className="text-white font-semibold text-xs tracking-wider uppercase mb-3">
              Emergency Contacts
            </h4>
            <p className="text-slate-400 mb-2 leading-relaxed">
              For active fires, gas leaks, or major structural flooding, call campus emergency dispatch immediately.
            </p>
            <div className="bg-slate-800/80 rounded-lg p-2.5 border border-slate-700 space-y-1 font-mono text-[11px]">
              <div className="text-amber-300 font-semibold">Campus Police &amp; Fire: (555) 019-911</div>
              <div className="text-blue-300">Facilities Emergency Desk: ext. 4444</div>
            </div>
          </div>
        </div>

        <div className="pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-500 text-[11px]">
          <div>
            &copy; {new Date().getFullYear()} CampusConnect. Built with Google AI Studio.
          </div>
          <div className="flex items-center gap-4">
            <span>Persistence: Server File Storage (<code>.data/tickets.json</code>)</span>
            <span>All AI suggestions are reviewed by human staff</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
