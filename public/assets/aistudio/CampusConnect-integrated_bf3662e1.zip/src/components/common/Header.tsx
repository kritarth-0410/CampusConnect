import React from 'react';
import {
  Building2,
  Sparkles,
  ShieldAlert,
  HardHat,
  Search,
  PlusCircle,
  PlaySquare,
  Server
} from 'lucide-react';

export type AppView = 'student' | 'staff' | 'track' | 'demo';

interface HeaderProps {
  currentView: AppView;
  onNavigate: (view: AppView, ticketIdToTrack?: string) => void;
  serverStatus?: {
    geminiConfigured: boolean;
    storage?: { storageType: string; recordCount: number };
  };
  onOpenDemoGuide: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  onNavigate,
  serverStatus,
  onOpenDemoGuide
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      {/* Top emergency disclaimer bar */}
      <div className="bg-slate-900 text-slate-300 text-xs px-4 py-1.5 flex flex-wrap items-center justify-between gap-2 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold bg-rose-500/20 text-rose-300 border border-rose-500/30">
            CAMPUS FACILITY ALERT
          </span>
          <span className="hidden sm:inline">Active monitoring for Plumbing, Electricity, Cleanliness & Internet issues.</span>
        </div>
        <div className="flex items-center gap-4 text-[11px]">
          <span className="flex items-center gap-1.5">
            {serverStatus?.geminiConfigured ? (
              <>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-emerald-400 font-medium">Gemini 3.8 Flash Active</span>
              </>
            ) : serverStatus?.geminiConfigured === false ? (
              <>
                <span className="w-2 h-2 rounded-full bg-amber-400" />
                <span className="text-amber-300 font-medium">Heuristic Triage (Set GEMINI_API_KEY)</span>
              </>
            ) : (
              <>
                <span className="w-2 h-2 rounded-full bg-slate-400 animate-pulse" />
                <span className="text-slate-300 font-medium">AI Triage Ready</span>
              </>
            )}
          </span>
          <span className="hidden md:flex items-center gap-1 text-slate-400">
            <Server size={11} />
            <span>Disk-backed Persistence</span>
          </span>
          <span className="text-amber-300 font-mono">Emergency: ext. 4444</span>
        </div>
      </div>

      {/* Main navigation bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Logo & Brand */}
          <div
            className="flex items-center gap-3 cursor-pointer group"
            onClick={() => onNavigate('student')}
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-700 via-indigo-600 to-sky-500 flex items-center justify-center text-white shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg tracking-tight text-slate-900">
                  Campus<span className="text-blue-600">Connect</span>
                </span>
                <span className="text-[10px] font-bold uppercase tracking-wider bg-blue-100 text-blue-800 px-1.5 py-0.5 rounded">
                  Hackathon MVP
                </span>
              </div>
              <p className="text-xs text-slate-500 hidden sm:block">
                AI Maintenance Triage &amp; Resolution System
              </p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs sm:text-sm font-medium">
            <button
              onClick={() => onNavigate('student')}
              className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
                currentView === 'student'
                  ? 'bg-white text-blue-700 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              <PlusCircle size={15} />
              <span>Student Portal</span>
            </button>

            <button
              onClick={() => onNavigate('track')}
              className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
                currentView === 'track'
                  ? 'bg-white text-blue-700 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              <Search size={15} />
              <span>Track Ticket</span>
            </button>

            <button
              onClick={() => onNavigate('staff')}
              className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
                currentView === 'staff'
                  ? 'bg-slate-900 text-white shadow-xs font-semibold'
                  : 'text-slate-700 hover:text-slate-950 hover:bg-slate-200/60'
              }`}
            >
              <HardHat size={15} className="text-amber-400" />
              <span>Staff Dashboard</span>
              <span className="ml-1 text-[10px] bg-amber-400/20 text-amber-300 px-1 py-0.2 rounded font-mono">
                SIM
              </span>
            </button>
          </nav>

          {/* Action CTAs: Interactive Demo Guide & Report Button */}
          <div className="flex items-center gap-2">
            <button
              onClick={onOpenDemoGuide}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-gradient-to-r from-purple-600 to-indigo-600 text-white hover:from-purple-700 hover:to-indigo-700 shadow-xs transition-all hover:shadow-purple-500/20 hover:scale-[1.02] cursor-pointer"
              title="Launch the 7-Step Hackathon Demo Walkthrough"
            >
              <PlaySquare size={14} className="text-purple-200" />
              <span className="hidden md:inline">Demo Walkthrough</span>
              <span className="md:hidden">Demo</span>
            </button>

            <button
              onClick={() => onNavigate('student')}
              className="hidden lg:inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-blue-600 text-white hover:bg-blue-700 shadow-xs transition-colors cursor-pointer"
            >
              <PlusCircle size={14} />
              <span>New Complaint</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
