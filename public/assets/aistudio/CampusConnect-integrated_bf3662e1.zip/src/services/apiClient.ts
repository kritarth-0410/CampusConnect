/**
 * Frontend API Client for CampusConnect
 * Interacts with /api endpoints on the Express full-stack server
 */

import {
  AnalyzeComplaintRequest,
  AnalyzeComplaintResponse,
  AssignTicketRequest,
  SubmitComplaintRequest,
  SubmitComplaintResponse,
  Ticket,
  TicketDetailResponse,
  TicketHistoryResponse,
  TicketListResponse,
  UpdateTicketStatusRequest
} from '../shared/types.js';

class ApiClient {
  private async request<T>(endpoint: string, options?: RequestInit): Promise<T> {
    const res = await fetch(endpoint, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(options?.headers || {})
      }
    });

    if (!res.ok) {
      let errorMsg = `Request failed with status ${res.status}`;
      try {
        const errorData = await res.json();
        if (errorData.error) errorMsg = errorData.error;
      } catch {
        // Fallback to text
      }
      throw new Error(errorMsg);
    }

    return res.json() as Promise<T>;
  }

  // Analyze complaint with Gemini AI
  public async analyzeComplaint(payload: AnalyzeComplaintRequest): Promise<AnalyzeComplaintResponse> {
    return this.request<AnalyzeComplaintResponse>('/api/complaints/analyze', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  }

  // Submit complaint
  public async submitComplaint(payload: SubmitComplaintRequest): Promise<SubmitComplaintResponse> {
    return this.request<SubmitComplaintResponse>('/api/complaints/submit', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  }

  // Get ticket listing with optional filters
  public async getTickets(params?: {
    category?: string;
    status?: string;
    query?: string;
    building?: string;
    department?: string;
  }): Promise<TicketListResponse> {
    const searchParams = new URLSearchParams();
    if (params?.category && params.category !== 'ALL') searchParams.set('category', params.category);
    if (params?.status && params.status !== 'ALL') searchParams.set('status', params.status);
    if (params?.department && params.department !== 'ALL') searchParams.set('department', params.department);
    if (params?.query) searchParams.set('query', params.query);
    if (params?.building && params.building !== 'ALL') searchParams.set('building', params.building);

    const qs = searchParams.toString();
    return this.request<TicketListResponse>(`/api/tickets${qs ? `?${qs}` : ''}`);
  }

  // Lookup single ticket by ID
  public async getTicketById(id: string): Promise<TicketDetailResponse> {
    return this.request<TicketDetailResponse>(`/api/tickets/${encodeURIComponent(id)}`);
  }

  // Assign ticket
  public async assignTicket(id: string, payload: AssignTicketRequest): Promise<{ success: boolean; ticket: Ticket; message: string }> {
    return this.request(`/api/tickets/${encodeURIComponent(id)}/assign`, {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  }

  // Update ticket status
  public async updateStatus(id: string, payload: UpdateTicketStatusRequest): Promise<{ success: boolean; ticket: Ticket; message: string }> {
    return this.request(`/api/tickets/${encodeURIComponent(id)}/status`, {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  }

  // Get ticket history
  public async getTicketHistory(id: string): Promise<TicketHistoryResponse> {
    return this.request<TicketHistoryResponse>(`/api/tickets/${encodeURIComponent(id)}/history`);
  }

  // Check health and storage
  public async checkHealth(): Promise<any> {
    return this.request('/api/health');
  }
}

export const apiClient = new ApiClient();
