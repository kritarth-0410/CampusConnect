import React, { useState, useEffect } from 'react';
import { Header, AppView } from './components/common/Header.js';
import { Footer } from './components/common/Footer.js';
import { StudentPortal } from './components/student/StudentPortal.js';
import { StaffDashboard } from './components/staff/StaffDashboard.js';
import { DemoWalkthroughModal } from './components/demo/DemoWalkthroughModal.js';
import { apiClient } from './services/apiClient.js';

export default function App() {
  const [currentView, setCurrentView] = useState<AppView>('student');
  const [ticketToTrack, setTicketToTrack] = useState<string>('');
  const [isDemoModalOpen, setIsDemoModalOpen] = useState(false);
  const [serverHealth, setServerHealth] = useState<{
    geminiConfigured: boolean;
    storage?: { storageType: string; recordCount: number };
  } | undefined>(undefined);

  // Check server health and disk persistence on mount
  useEffect(() => {
    apiClient.checkHealth()
      .then((data) => {
        setServerHealth({
          geminiConfigured: data.geminiConfigured,
          storage: data.storage
        });
      })
      .catch((err) => {
        console.warn('[App] Health check failed:', err);
      });
  }, []);

  const handleNavigate = (view: AppView, ticketId?: string) => {
    if (ticketId) {
      setTicketToTrack(ticketId);
    }
    setCurrentView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900 antialiased selection:bg-blue-600 selection:text-white">
      {/* Top Navigation */}
      <Header
        currentView={currentView}
        onNavigate={handleNavigate}
        serverStatus={serverHealth}
        onOpenDemoGuide={() => setIsDemoModalOpen(true)}
      />

      {/* Main View Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {currentView === 'student' && (
          <StudentPortal
            initialMode="report"
            onNavigateToStaff={() => handleNavigate('staff')}
            onOpenDemoGuide={() => setIsDemoModalOpen(true)}
          />
        )}

        {currentView === 'track' && (
          <StudentPortal
            initialMode="track"
            initialTicketId={ticketToTrack}
            onNavigateToStaff={() => handleNavigate('staff')}
            onOpenDemoGuide={() => setIsDemoModalOpen(true)}
          />
        )}

        {currentView === 'staff' && (
          <StaffDashboard
            onOpenDemoGuide={() => setIsDemoModalOpen(true)}
          />
        )}
      </main>

      {/* Footer */}
      <Footer />

      {/* Interactive 7-Step Hackathon Demo Modal */}
      <DemoWalkthroughModal
        isOpen={isDemoModalOpen}
        onClose={() => setIsDemoModalOpen(false)}
        onNavigate={handleNavigate}
      />
    </div>
  );
}
