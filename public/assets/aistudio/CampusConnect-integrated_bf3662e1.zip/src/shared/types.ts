/**
 * CampusConnect - Shared Data Models and API Contracts
 * Co-developed for 4-Person Collaboration
 * Person 3 & Person 1 shared interface boundary
 */

export const TICKET_CATEGORIES = [
  'Plumbing',
  'Electricity',
  'Cleanliness',
  'Internet Connectivity'
] as const;

export type TicketCategory = typeof TICKET_CATEGORIES[number];

export const TICKET_STATUSES = [
  'Submitted',
  'Under Review',
  'Assigned',
  'In Progress',
  'Resolved'
] as const;

export type TicketStatus = typeof TICKET_STATUSES[number];

export const DEPARTMENTS = [
  'Plumbing Maintenance Department',
  'Electrical Systems & Safety Division',
  'Campus Custodial & Sanitation Services',
  'IT & Network Infrastructure Team'
] as const;

export type Department = typeof DEPARTMENTS[number];

export const CATEGORY_DEPARTMENT_ROUTING: Record<TicketCategory, Department> = {
  'Plumbing': 'Plumbing Maintenance Department',
  'Electricity': 'Electrical Systems & Safety Division',
  'Cleanliness': 'Campus Custodial & Sanitation Services',
  'Internet Connectivity': 'IT & Network Infrastructure Team'
};

export interface StatusHistoryEntry {
  id: string;
  ticketId: string;
  fromStatus?: TicketStatus;
  toStatus: TicketStatus;
  changedAt: string; // ISO 8601 string
  changedBy: string; // name or role
  notes?: string;
}

export interface Assignment {
  department: Department;
  assignedTo?: string; // Technician or officer name
  assignedAt: string;
  assignedBy: string;
  priority: 'Low' | 'Medium' | 'High' | 'Emergency';
  notes?: string;
}

export interface AIAnalysis {
  suggestedCategory: TicketCategory;
  confidence: 'High' | 'Medium' | 'Low';
  confidenceScore: number; // 0.0 to 1.0
  conciseSummary: string;
  recommendedDepartment: Department;
  missingDetailsIdentified: string[];
  followUpQuestions: string[];
  imageObservations?: string;
  urgencyAssessment: 'Routine' | 'Moderate' | 'Urgent' | 'Safety Hazard';
  departmentRoutingReason?: string;
  analyzedAt: string;
  isAiFallback?: boolean; // true if fallback heuristic was used
}

export interface DuplicateCandidate {
  ticketId: string;
  title: string;
  category: TicketCategory;
  location: string;
  status: TicketStatus;
  similarityScore: number; // 0.0 to 1.0
  matchReason: string;
}

export interface Ticket {
  id: string; // e.g. "CC-1042"
  title: string;
  description: string;
  rawStudentInput: string;
  category: TicketCategory;
  categorySource: 'student' | 'ai_suggested' | 'staff_override';
  location: string;
  building: string;
  roomOrArea?: string;
  studentName?: string;
  studentEmail?: string;
  studentContactConsent?: boolean;
  imageUrl?: string;
  imageDataUri?: string;
  status: TicketStatus;
  createdAt: string;
  updatedAt: string;
  resolvedAt?: string;
  aiAnalysis?: AIAnalysis;
  assignment?: Assignment;
  statusHistory: StatusHistoryEntry[];
  duplicateWarnings?: DuplicateCandidate[];
  studentFollowUpAnswers?: Record<string, string>;
  staffNotes?: string[];
}

/**
 * API Contracts
 */

export interface AnalyzeComplaintRequest {
  description: string;
  location?: string;
  building?: string;
  imageBase64?: string; // optional image payload
  mimeType?: string;
}

export interface AnalyzeComplaintResponse {
  success: boolean;
  analysis: AIAnalysis;
  duplicateCandidates: DuplicateCandidate[];
  message?: string;
}

export interface SubmitComplaintRequest {
  description: string;
  location: string;
  building: string;
  roomOrArea?: string;
  category: TicketCategory;
  categorySource?: 'student' | 'ai_suggested';
  studentName?: string;
  studentEmail?: string;
  imageBase64?: string;
  mimeType?: string;
  aiAnalysis?: AIAnalysis;
  studentFollowUpAnswers?: Record<string, string>;
}

export interface SubmitComplaintResponse {
  success: boolean;
  ticket?: Ticket;
  error?: string;
  duplicateWarnings?: DuplicateCandidate[];
}

export interface TicketListResponse {
  success: boolean;
  tickets: Ticket[];
  total: number;
  stats: {
    total: number;
    submitted: number;
    underReview: number;
    assigned: number;
    inProgress: number;
    resolved: number;
    byCategory: Record<TicketCategory, number>;
  };
}

export interface TicketDetailResponse {
  success: boolean;
  ticket?: Ticket;
  error?: string;
}

export interface AssignTicketRequest {
  department: Department;
  assignedTo?: string;
  priority: 'Low' | 'Medium' | 'High' | 'Emergency';
  notes?: string;
  assignedBy?: string;
}

export interface UpdateTicketStatusRequest {
  status: TicketStatus;
  notes?: string;
  changedBy?: string;
}

export interface TicketHistoryResponse {
  success: boolean;
  ticketId: string;
  history: StatusHistoryEntry[];
}
