/**
 * CampusConnect - Full-Stack Application Server
 * Combines Express API endpoints with Vite dev middleware
 * Host: 0.0.0.0, Port: 3000
 */

import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import {
  TICKET_CATEGORIES,
  TICKET_STATUSES,
  DEPARTMENTS,
  TicketCategory,
  TicketStatus,
  Department,
  CATEGORY_DEPARTMENT_ROUTING
} from './src/shared/types.js';
import {
  analyzeComplaintWithGemini,
  detectDuplicateCandidates
} from './src/server/geminiService.js';
import { ticketRepository } from './src/server/ticketStore.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const isProduction = process.env.NODE_ENV === 'production';
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

async function createServer() {
  const app = express();

  // Middleware for JSON bodies (supports up to 10MB for base64 photo attachments)
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true, limit: '10mb' }));

  // API Route: Health & System Diagnostics
  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({
      status: 'ok',
      service: 'CampusConnect Server',
      timestamp: new Date().toISOString(),
      geminiConfigured: Boolean(process.env.GEMINI_API_KEY),
      storage: ticketRepository.getStorageStatus()
    });
  });

  // API Route: Analyze Complaint with Gemini AI
  app.post('/api/complaints/analyze', async (req: Request, res: Response) => {
    try {
      const { description, location, building, imageBase64, mimeType } = req.body;

      if (!description || typeof description !== 'string' || description.trim().length === 0) {
        return res.status(400).json({
          success: false,
          error: 'Complaint description is required for triage analysis.'
        });
      }

      // 1. Run Gemini AI analysis
      const analysis = await analyzeComplaintWithGemini({
        description: description.trim(),
        location: location ? String(location).trim() : undefined,
        building: building ? String(building).trim() : undefined,
        imageBase64,
        mimeType
      });

      // 2. Scan active tickets for potential duplicates
      const existingTickets = ticketRepository.getAll();
      const duplicateCandidates = detectDuplicateCandidates(
        {
          description,
          category: analysis.suggestedCategory,
          location,
          building
        },
        existingTickets
      );

      return res.json({
        success: true,
        analysis,
        duplicateCandidates
      });
    } catch (error: any) {
      console.error('[API /api/complaints/analyze Error]', error);
      return res.status(500).json({
        success: false,
        error: error.message || 'Internal error during complaint analysis'
      });
    }
  });

  // API Route: Submit Complaint
  app.post('/api/complaints/submit', async (req: Request, res: Response) => {
    try {
      const {
        description,
        location,
        building,
        roomOrArea,
        category,
        categorySource,
        studentName,
        studentEmail,
        imageBase64,
        mimeType,
        aiAnalysis,
        studentFollowUpAnswers
      } = req.body;

      if (!description || !description.trim()) {
        return res.status(400).json({ success: false, error: 'Description is required' });
      }

      if (!building || !building.trim()) {
        return res.status(400).json({ success: false, error: 'Campus building is required' });
      }

      if (!location || !location.trim()) {
        return res.status(400).json({ success: false, error: 'Specific location or room is required' });
      }

      // Validate category strictly matches 4 allowed
      if (!TICKET_CATEGORIES.includes(category as TicketCategory)) {
        return res.status(400).json({
          success: false,
          error: `Invalid category: "${category}". Must be one of: ${TICKET_CATEGORIES.join(', ')}`
        });
      }

      // Detect duplicates to attach as warning flags on the ticket for staff
      const existingTickets = ticketRepository.getAll();
      const duplicateWarnings = detectDuplicateCandidates(
        { description, category, location, building },
        existingTickets
      );

      const ticket = ticketRepository.createTicket({
        description: description.trim(),
        location: location.trim(),
        building: building.trim(),
        roomOrArea: roomOrArea ? roomOrArea.trim() : undefined,
        category,
        categorySource: categorySource || 'student',
        studentName: studentName ? studentName.trim() : undefined,
        studentEmail: studentEmail ? studentEmail.trim() : undefined,
        imageBase64,
        mimeType,
        aiAnalysis,
        studentFollowUpAnswers,
        duplicateWarnings
      });

      return res.status(201).json({
        success: true,
        ticket,
        duplicateWarnings
      });
    } catch (error: any) {
      console.error('[API /api/complaints/submit Error]', error);
      return res.status(500).json({
        success: false,
        error: error.message || 'Failed to submit complaint'
      });
    }
  });

  // API Route: List Tickets with filters
  app.get('/api/tickets', (req: Request, res: Response) => {
    try {
      let tickets = ticketRepository.getAll();
      const { category, status, query, building, department } = req.query;

      if (category && typeof category === 'string' && category !== 'ALL') {
        tickets = tickets.filter(t => t.category === category);
      }

      if (status && typeof status === 'string' && status !== 'ALL') {
        tickets = tickets.filter(t => t.status === status);
      }

      if (department && typeof department === 'string' && department !== 'ALL') {
        tickets = tickets.filter(t =>
          (t.assignment && t.assignment.department === department) ||
          (!t.assignment && (t.aiAnalysis?.recommendedDepartment === department || CATEGORY_DEPARTMENT_ROUTING[t.category] === department))
        );
      }

      if (building && typeof building === 'string' && building !== 'ALL') {
        tickets = tickets.filter(t => t.building.toLowerCase().includes(building.toLowerCase()));
      }

      if (query && typeof query === 'string' && query.trim()) {
        const rawQ = query.trim().toLowerCase();
        // Support searching with or without CC- prefix or # prefix
        const cleanIdQ = rawQ.replace(/^#/, '').trim();
        const numOnlyMatch = /^\d+$/.test(cleanIdQ) ? `cc-${cleanIdQ}` : null;

        tickets = tickets.filter(
          t => {
            const ticketIdLower = t.id.toLowerCase();
            return (
              ticketIdLower.includes(rawQ) ||
              ticketIdLower.includes(cleanIdQ) ||
              (numOnlyMatch && ticketIdLower === numOnlyMatch) ||
              t.title.toLowerCase().includes(rawQ) ||
              t.description.toLowerCase().includes(rawQ) ||
              t.location.toLowerCase().includes(rawQ) ||
              t.building.toLowerCase().includes(rawQ) ||
              (t.assignment?.assignedTo && t.assignment.assignedTo.toLowerCase().includes(rawQ)) ||
              (t.studentName && t.studentName.toLowerCase().includes(rawQ))
            );
          }
        );
      }

      return res.json({
        success: true,
        tickets,
        total: tickets.length,
        stats: ticketRepository.getStats()
      });
    } catch (error: any) {
      return res.status(500).json({ success: false, error: error.message });
    }
  });

  // API Route: Ticket Lookup by ID
  app.get('/api/tickets/:id', (req: Request, res: Response) => {
    const rawId = req.params.id;
    let cleanId = rawId.trim().toUpperCase();
    if (/^\d+$/.test(cleanId)) {
      cleanId = `CC-${cleanId}`;
    }

    const ticket = ticketRepository.getById(cleanId);
    if (!ticket) {
      return res.status(404).json({
        success: false,
        error: `No ticket found with ID "${rawId}". Please double-check the ID format (e.g. CC-1001).`
      });
    }

    return res.json({
      success: true,
      ticket
    });
  });

  // API Route: Assign Ticket
  app.post('/api/tickets/:id/assign', (req: Request, res: Response) => {
    const { id } = req.params;
    const { department, assignedTo, priority, notes, assignedBy } = req.body;

    if (!department || !DEPARTMENTS.includes(department as Department)) {
      return res.status(400).json({
        success: false,
        error: `Department must be one of: ${DEPARTMENTS.join(', ')}`
      });
    }

    const validPriorities = ['Low', 'Medium', 'High', 'Emergency'];
    const p = validPriorities.includes(priority) ? priority : 'Medium';

    const ticket = ticketRepository.assignTicket(
      id,
      department as Department,
      assignedTo,
      p,
      notes,
      assignedBy || 'Staff Supervisor'
    );

    if (!ticket) {
      return res.status(404).json({ success: false, error: `Ticket ${id} not found` });
    }

    return res.json({
      success: true,
      ticket,
      message: `Ticket ${id} assigned to ${department}`
    });
  });

  // API Route: Update Status
  app.post('/api/tickets/:id/status', (req: Request, res: Response) => {
    const { id } = req.params;
    const { status, notes, changedBy } = req.body;

    if (!status || !TICKET_STATUSES.includes(status as TicketStatus)) {
      return res.status(400).json({
        success: false,
        error: `Status must be exactly one of: ${TICKET_STATUSES.join(', ')}`
      });
    }

    const ticket = ticketRepository.updateStatus(
      id,
      status as TicketStatus,
      notes,
      changedBy || 'Staff Dispatcher'
    );

    if (!ticket) {
      return res.status(404).json({ success: false, error: `Ticket ${id} not found` });
    }

    return res.json({
      success: true,
      ticket,
      message: `Status updated to ${status}`
    });
  });

  // API Route: Ticket History
  app.get('/api/tickets/:id/history', (req: Request, res: Response) => {
    const { id } = req.params;
    const ticket = ticketRepository.getById(id);

    if (!ticket) {
      return res.status(404).json({ success: false, error: `Ticket ${id} not found` });
    }

    return res.json({
      success: true,
      ticketId: ticket.id,
      history: ticket.statusHistory
    });
  });

  // Storage Diagnostics Endpoint
  app.get('/api/storage/status', (_req: Request, res: Response) => {
    res.json({
      success: true,
      storage: ticketRepository.getStorageStatus()
    });
  });

  // Vite middleware in dev or static files in production
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[CampusConnect Server] Running at http://0.0.0.0:${PORT} (env: ${isProduction ? 'prod' : 'dev'})`);
  });
}

createServer().catch((err) => {
  console.error('[CampusConnect Fatal Server Startup Error]', err);
  process.exit(1);
});
