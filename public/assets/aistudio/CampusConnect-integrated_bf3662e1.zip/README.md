# CampusConnect — Integration Build

This ZIP is a first-pass integration of the original CampusConnect app with selected teammate changes.

## Included
- Original project as the base.
- Updated staff dashboard, staff metrics, ticket detail modal, staff utilities, API client and server from the staff-focused project.
- Updated Gemini service, shared types, complaint form, and header from the AI-focused project.
- Existing original ticket-store/backend architecture retained to avoid replacing it with an incompatible alternative.

## Important integration note
The backend-focused ZIP introduced a separate `ticketService`/storage architecture and a different server API. Those files were **not automatically substituted** because that would replace the original backend wiring and could break existing API contracts. They need a deliberate follow-up merge after contract-level testing.

## Run locally
1. Install Node.js (LTS).
2. Run `npm install`.
3. Set `GEMINI_API_KEY` in `.env.local` if using Gemini features.
4. Run `npm run build` and `npm run lint`.
5. Run `npm run dev`.

## Status
This integration has not been successfully built/tested in this environment because dependency installation did not complete. Run the build and lint commands before deployment. Do not force-push this ZIP over `main`; commit to a review branch and open a pull request after tests pass.
